"""Acceso a SQLite.

Un TPV de una caja tiene poca concurrencia, así que se usa una sola conexión
protegida por un candado: las escrituras quedan serializadas y no hay carreras
entre peticiones. Cada operación de negocio va en una transacción IMMEDIATE.
"""

from __future__ import annotations

import re
import sqlite3
import threading
from contextlib import contextmanager
from datetime import datetime, timezone
from importlib import resources
from pathlib import Path
from typing import Iterator, Sequence

_MIGRATION_NAME = re.compile(r"^(\d{3})_[a-z0-9_]+\.sql$")


def utc_now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%fZ")


def local_today() -> str:
    return datetime.now().astimezone().date().isoformat()


def bundled_migrations() -> list[tuple[int, str]]:
    """Migraciones del paquete, ordenadas: migrations/NNN_nombre.sql."""
    found = []
    for entry in resources.files("tpv.migrations").iterdir():
        match = _MIGRATION_NAME.match(entry.name)
        if match:
            found.append((int(match.group(1)), entry.read_text(encoding="utf-8")))
    found.sort()
    versions = [v for v, _ in found]
    if versions != list(range(1, len(versions) + 1)):
        raise RuntimeError(f"Migraciones con huecos o repetidas: {versions}")
    return found


class Database:
    def __init__(self, path: Path | str, migrations: Sequence[tuple[int, str]] | None = None,
                 journal_mode: str = "WAL") -> None:
        if journal_mode not in ("WAL", "DELETE"):
            raise ValueError(f"journal_mode no válido: {journal_mode}")
        self.path = str(path)
        if self.path != ":memory:":
            Path(self.path).parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        self._conn = sqlite3.connect(self.path, isolation_level=None, check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._conn.execute("PRAGMA foreign_keys = ON")
        self._conn.execute("PRAGMA busy_timeout = 5000")
        if self.path != ":memory:":
            # En la app de la tablet (navegador) no hay memoria compartida para WAL: se usa
            # DELETE y así, tras cada transacción, todo está en el archivo que se guarda.
            self._conn.execute(f"PRAGMA journal_mode = {journal_mode}")
        # FULL: cada commit llega al disco antes de responder. Protege ante cortes de luz.
        self._conn.execute("PRAGMA synchronous = FULL")
        self._migrate(list(migrations) if migrations is not None else bundled_migrations())

    @property
    def schema_version(self) -> int:
        with self._lock:
            return self._conn.execute("PRAGMA user_version").fetchone()[0]

    def _migrate(self, migrations: list[tuple[int, str]]) -> None:
        latest = migrations[-1][0] if migrations else 0
        with self._lock:
            current = self.schema_version
            if current > latest:
                raise RuntimeError(
                    f"La base de datos es de una versión más nueva ({current}) que el programa ({latest}). "
                    "Instala la versión más reciente del TPV."
                )
            pending = [(v, sql) for v, sql in migrations if v > current]
            if not pending:
                return
            if current > 0 and self.path != ":memory:":
                # Antes de tocar una base con datos, copia de seguridad completa.
                self.backup_to(Path(self.path).with_name(f"tpv.antes-de-v{pending[0][0]}.sqlite3"))
            for version, sql in pending:
                self._conn.execute("BEGIN IMMEDIATE")
                try:
                    for statement in _split_sql(sql):
                        self._conn.execute(statement)
                    self._conn.execute(f"PRAGMA user_version = {int(version)}")
                    self._conn.execute("COMMIT")
                except BaseException:
                    self._rollback_quietly()
                    raise

    def _rollback_quietly(self) -> None:
        """Deshace lo pendiente sin ocultar el error original.

        Si un COMMIT falla (disco lleno, fallo de escritura) la transacción puede
        quedar abierta; sin este paso, el siguiente BEGIN fallaría y la caja se
        quedaría sin poder guardar ventas hasta reiniciar.
        """
        if self._conn.in_transaction:
            try:
                self._conn.execute("ROLLBACK")
            except sqlite3.Error:
                pass

    @contextmanager
    def tx(self) -> Iterator[sqlite3.Connection]:
        """Transacción de escritura: todo o nada."""
        with self._lock:
            self._conn.execute("BEGIN IMMEDIATE")
            try:
                yield self._conn
                self._conn.execute("COMMIT")
            except BaseException:
                self._rollback_quietly()
                raise

    @contextmanager
    def read(self) -> Iterator[sqlite3.Connection]:
        """Lectura con una instantánea coherente."""
        with self._lock:
            self._conn.execute("BEGIN")
            try:
                yield self._conn
            finally:
                self._rollback_quietly()

    def backup_to(self, target: Path | str) -> None:
        """Copia consistente aunque la base esté en uso (API de copia de SQLite)."""
        with self._lock:
            dest = sqlite3.connect(str(target))
            try:
                self._conn.backup(dest)
            finally:
                dest.close()

    def close(self) -> None:
        with self._lock:
            self._conn.close()


def _split_sql(script: str) -> list[str]:
    """Divide el script en sentencias completas, respetando los cuerpos de los triggers."""
    statements: list[str] = []
    buffer = ""
    for line in script.splitlines(keepends=True):
        if line.lstrip().startswith("--"):
            continue
        buffer += line
        if sqlite3.complete_statement(buffer):
            if buffer.strip():
                statements.append(buffer.strip())
            buffer = ""
    if buffer.strip():
        raise ValueError("El script SQL termina con una sentencia incompleta")
    return statements
