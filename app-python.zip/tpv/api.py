"""API REST interna. La interfaz (PC y, en la fase 2, móviles) habla siempre por aquí."""

from __future__ import annotations

import logging
import mimetypes
import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from typing import Annotated, Literal

from fastapi import Depends, FastAPI, Request, Response
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles
from starlette.middleware.trustedhost import TrustedHostMiddleware
from pydantic import BaseModel, ConfigDict, Field

from . import __version__, admin, catalog, excel, inventory, reports, reset, sales, shifts, tabs
from .backup import BackupManager
from .carpeta import BACKUPS, CLOSINGS, REPORTS, ExportFolder
from .config import Settings
from .db import Database
from .errors import Conflict, DomainError, Unauthorized
from .security import AdminSessions, verify_password

COOKIE = "tpv_admin"
log = logging.getLogger("tpv")

# En Windows el registro puede asociar .js a text/plain y el navegador rechazaría los módulos.
mimetypes.add_type("text/javascript", ".js")
mimetypes.add_type("text/css", ".css")
mimetypes.add_type("image/svg+xml", ".svg")
mimetypes.add_type("application/manifest+json", ".webmanifest")

# Dinero y cantidades: enteros estrictos. 12.5 o "12" se rechazan.
Cents = Annotated[int, Field(strict=True, ge=0, le=100_000_000)]
PositiveCents = Annotated[int, Field(strict=True, gt=0, le=100_000_000)]
Qty = Annotated[int, Field(strict=True, gt=0, le=10_000_000)]
NonNegQty = Annotated[int, Field(strict=True, ge=0, le=10_000_000)]
Id = Annotated[int, Field(strict=True, gt=0)]
Text = Annotated[str, Field(min_length=1, max_length=120)]
Note = Annotated[str, Field(max_length=300)]


class Model(BaseModel):
    model_config = ConfigDict(extra="forbid")


class PasswordIn(Model):
    password: Annotated[str, Field(min_length=1, max_length=200)]


class PasswordChangeIn(Model):
    current: Annotated[str, Field(min_length=1, max_length=200)]
    new: Annotated[str, Field(min_length=1, max_length=200)]


class CategoryIn(Model):
    name: Text
    color: Annotated[str, Field(pattern=r"^#[0-9A-Fa-f]{6}$")]
    position: NonNegQty | None = None


class CategoryPatch(Model):
    name: Text | None = None
    color: Annotated[str, Field(pattern=r"^#[0-9A-Fa-f]{6}$")] | None = None
    position: NonNegQty | None = None


class RecipeItemIn(Model):
    ingredient_id: Id
    qty: Qty


class OptionIn(Model):
    grp: Literal["licor", "refresco"]
    label: Annotated[str, Field(max_length=120)] = ""
    ingredient_id: Id | None = None
    qty: NonNegQty = 0
    price_cents: Cents | None = None


class ProductIn(Model):
    category_id: Id
    name: Text
    kind: Literal["simple", "combinado"] = "simple"
    price_cents: Cents = 0
    recipe: list[RecipeItemIn] = []
    options: list[OptionIn] = []
    position: NonNegQty | None = None
    active: bool = True


class ProductPatch(Model):
    category_id: Id | None = None
    name: Text | None = None
    price_cents: Cents | None = None
    position: NonNegQty | None = None
    active: bool | None = None
    recipe: list[RecipeItemIn] | None = None
    options: list[OptionIn] | None = None


class IngredientIn(Model):
    name: Text
    unit: Literal["ml", "ud", "racion"]
    package_size: Qty
    package_label: Annotated[str, Field(max_length=120)] = ""
    min_stock: NonNegQty = 0
    initial_qty: NonNegQty = 0
    initial_total_cents: Cents = 0


class IngredientPatch(Model):
    name: Text | None = None
    unit: Literal["ml", "ud", "racion"] | None = None
    package_size: Qty | None = None
    package_label: Annotated[str, Field(max_length=120)] | None = None
    min_stock: NonNegQty | None = None


class EntryIn(Model):
    qty: Qty
    total_cents: Cents
    kind: Literal["compra", "produccion"] = "compra"
    note: Note | None = None


class WasteIn(Model):
    qty: Qty
    note: Annotated[str, Field(min_length=1, max_length=300)]


class CountItemIn(Model):
    ingredient_id: Id
    counted: NonNegQty


class CountIn(Model):
    items: Annotated[list[CountItemIn], Field(min_length=1)]
    note: Note | None = None


class OpenShiftIn(Model):
    opening_float_cents: Cents


class CloseShiftIn(Model):
    counted_cash_cents: Cents
    next_float_cents: Cents
    breakdown: dict[str, NonNegQty] | None = None


class CashMovementIn(Model):
    direction: Literal["entrada", "salida"]
    amount_cents: PositiveCents
    concept: Annotated[str, Field(min_length=1, max_length=200)]


class SaleLineIn(Model):
    product_id: Id
    qty: Annotated[int, Field(strict=True, ge=1, le=sales.MAX_LINE_QTY)]
    unit_price_cents: Cents
    licor_option_id: Id | None = None
    refresco_option_id: Id | None = None


class SaleIn(Model):
    id: Annotated[str, Field(min_length=32, max_length=36)]
    kind: Literal["venta", "invitacion"] = "venta"
    # Al cobrar una cuenta abierta (tab_id) las líneas salen de la cuenta guardada.
    lines: Annotated[list[SaleLineIn], Field(max_length=200)] = []
    payment_method: Literal["efectivo"] = "efectivo"
    tendered_cents: Cents | None = None
    note: Note | None = None
    device_id: Annotated[str, Field(min_length=1, max_length=64)] = "pc"
    client_created_at: Annotated[str, Field(max_length=40)] | None = None
    queued: bool = False
    tab_id: Id | None = None
    tab_version: Id | None = None


class TabLineIn(Model):
    product_id: Id
    qty: Annotated[int, Field(strict=True, ge=1, le=sales.MAX_LINE_QTY)]
    unit_price_cents: Cents
    licor_option_id: Id | None = None
    refresco_option_id: Id | None = None


TabName = Annotated[str, Field(min_length=1, max_length=60)]
DeviceId = Annotated[str, Field(min_length=1, max_length=64)]


class TabIn(Model):
    name: TabName
    lines: Annotated[list[TabLineIn], Field(max_length=200)] = []
    device_id: DeviceId = "pc"


class TabPatch(Model):
    version: Id
    name: TabName | None = None
    lines: Annotated[list[TabLineIn], Field(max_length=200)] | None = None
    device_id: DeviceId = "pc"


class TabCancelIn(Model):
    reason: Note | None = None
    device_id: DeviceId = "pc"


class VoidIn(Model):
    id: Annotated[str, Field(min_length=32, max_length=36)]
    sale_id: Annotated[str, Field(min_length=32, max_length=36)]
    line_id: Id | None = None
    qty: Qty | None = None
    reason: Annotated[str, Field(min_length=1, max_length=300)]


class StartRealIn(Model):
    confirm: Literal["EMPEZAR"]


XLSX = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"


class _RevalidatedStaticFiles(StaticFiles):
    """La interfaz se comprueba en cada carga (no-cache + ETag).

    Sin esto, tras actualizar el programa el navegador podía seguir usando algún
    .js antiguo de su caché mezclado con los nuevos.
    """

    def file_response(self, *args, **kwargs) -> Response:
        response = super().file_response(*args, **kwargs)
        response.headers["Cache-Control"] = "no-cache"
        return response


def _shift_filename(data: dict) -> str:
    return f"CPBAR_turno_{data['summary']['business_date']}_n{data['summary']['id']}.xlsx"


def _download(content: bytes, filename: str, media_type: str) -> Response:
    return Response(content, media_type=media_type,
                       headers={"Content-Disposition": f'attachment; filename="{filename}"', "Cache-Control": "no-store"})


class CartRemovalIn(Model):
    product_id: Id
    name: Text
    qty: Qty
    unit_price_cents: Cents
    device_id: Annotated[str, Field(min_length=1, max_length=64)] = "pc"


def create_app(settings: Settings, db: Database | None = None, backups: BackupManager | None = None) -> FastAPI:
    db = db or Database(settings.db_path)
    folder = ExportFolder(settings.export_dir)
    folder.ensure()
    backups = backups or BackupManager(
        db, settings.backup_dir, mirror=settings.export_dir / BACKUPS if settings.export_dir else None)
    sessions = AdminSessions()
    app = FastAPI(title="TPV CP BAR", version=__version__, docs_url=None, redoc_url=None, openapi_url=None)
    app.state.db = db
    app.state.sessions = sessions
    app.state.backups = backups
    app.state.folder = folder
    app.add_middleware(TrustedHostMiddleware, allowed_hosts=list(settings.allowed_hosts))

    @app.exception_handler(DomainError)
    def _domain_error(_: Request, exc: DomainError) -> JSONResponse:
        return JSONResponse(status_code=exc.status, content={"error": exc.code, "message": exc.message, "details": exc.details})

    @app.exception_handler(sqlite3.Error)
    def _storage_error(_: Request, exc: sqlite3.Error) -> JSONResponse:
        # La operación se ha deshecho entera; nada queda a medias.
        log.exception("Error de base de datos")
        return JSONResponse(status_code=503, content={
            "error": "storage_error",
            "message": "No se ha podido guardar. No se ha registrado nada. Inténtalo de nuevo; "
                       "si se repite, revisa que el disco no esté lleno y avisa al responsable.",
            "details": None,
        })

    def require_admin(request: Request) -> None:
        sessions.touch(request.cookies.get(COOKIE))

    Admin = Depends(require_admin)

    # --- Estado y administración ---------------------------------------

    @app.get("/api/health")
    def health() -> dict:
        return {"ok": True, "version": __version__}

    @app.get("/api/state")
    def state(request: Request) -> dict:
        with db.read() as c:
            shift = shifts.current_shift(c)
            return {
                "server_time": datetime.now(timezone.utc).isoformat(),
                "admin_configured": admin.is_configured(c),
                "is_admin": sessions.is_active(request.cookies.get(COOKIE)),
                "shift": shifts.shift_summary(c, shift["id"]) if shift else None,
                "suggested_float_cents": shifts.suggested_float(c),
                "demo_data": c.execute("SELECT 1 FROM meta WHERE key = 'demo_data'").fetchone() is not None,
                "last_sale_at": c.execute("SELECT MAX(created_at) FROM sales").fetchone()[0],
                "open_tabs": tabs.open_summary(c),
                "bar_name": excel.BAR_NAME,
                "version": __version__,
            }

    def _set_cookie(response: Response, token: str) -> None:
        response.set_cookie(COOKIE, token, httponly=True, samesite="strict", path="/api")

    @app.post("/api/admin/setup")
    def admin_setup(body: PasswordIn, response: Response) -> dict:
        with db.tx() as c:
            admin.setup_password(c, body.password)
        _set_cookie(response, sessions.create())
        return {"ok": True}

    @app.post("/api/admin/login")
    def admin_login(body: PasswordIn, response: Response) -> dict:
        sessions.check_not_locked()
        with db.read() as c:
            stored = admin.password_hash(c)
        if stored is None:
            raise Unauthorized("not_configured", "Todavía no hay contraseña de administración. Créala primero.")
        if not verify_password(body.password, stored):
            sessions.register_failure()
            raise Unauthorized("wrong_password", "Contraseña incorrecta.")
        _set_cookie(response, sessions.create())
        return {"ok": True}

    @app.post("/api/admin/logout")
    def admin_logout(request: Request, response: Response) -> dict:
        sessions.revoke(request.cookies.get(COOKIE))
        response.delete_cookie(COOKIE, path="/api")
        return {"ok": True}

    @app.post("/api/admin/password", dependencies=[Admin])
    def admin_password(body: PasswordChangeIn, request: Request, response: Response) -> dict:
        with db.tx() as c:
            admin.change_password(c, body.current, body.new)
        sessions.revoke_all()
        _set_cookie(response, sessions.create())
        return {"ok": True}

    # --- Catálogo -------------------------------------------------------

    @app.get("/api/catalog")
    def sale_catalog() -> dict:
        with db.read() as c:
            return catalog.sale_catalog(c)

    @app.get("/api/categories", dependencies=[Admin])
    def list_categories() -> list:
        with db.read() as c:
            return catalog.sale_catalog(c)["categories"]

    @app.post("/api/categories", dependencies=[Admin], status_code=201)
    def create_category(body: CategoryIn) -> dict:
        with db.tx() as c:
            return {"id": catalog.create_category(c, **body.model_dump())}

    @app.patch("/api/categories/{category_id}", dependencies=[Admin])
    def update_category(category_id: int, body: CategoryPatch) -> dict:
        with db.tx() as c:
            catalog.update_category(c, category_id, **body.model_dump())
        return {"ok": True}

    @app.delete("/api/categories/{category_id}", dependencies=[Admin])
    def delete_category(category_id: int) -> dict:
        with db.tx() as c:
            return {"result": catalog.delete_category(c, category_id)}

    @app.get("/api/products", dependencies=[Admin])
    def list_products() -> list:
        with db.read() as c:
            return catalog.list_products(c, with_costs=True, only_active=False)

    @app.post("/api/products", dependencies=[Admin], status_code=201)
    def create_product(body: ProductIn) -> dict:
        data = body.model_dump()
        with db.tx() as c:
            return {"id": catalog.create_product(c, **data)}

    @app.patch("/api/products/{product_id}", dependencies=[Admin])
    def update_product(product_id: int, body: ProductPatch) -> dict:
        with db.tx() as c:
            catalog.update_product(c, product_id, **body.model_dump())
        return {"ok": True}

    @app.delete("/api/products/{product_id}", dependencies=[Admin])
    def delete_product(product_id: int) -> dict:
        with db.tx() as c:
            return {"result": catalog.delete_product(c, product_id)}

    # --- Inventario -----------------------------------------------------

    @app.get("/api/ingredients", dependencies=[Admin])
    def list_ingredients() -> list:
        with db.read() as c:
            return inventory.list_ingredients(c)

    @app.post("/api/ingredients", dependencies=[Admin], status_code=201)
    def create_ingredient(body: IngredientIn) -> dict:
        with db.tx() as c:
            return {"id": inventory.create_ingredient(c, **body.model_dump())}

    @app.patch("/api/ingredients/{ingredient_id}", dependencies=[Admin])
    def update_ingredient(ingredient_id: int, body: IngredientPatch) -> dict:
        with db.tx() as c:
            inventory.update_ingredient(c, ingredient_id, **body.model_dump())
        return {"ok": True}

    @app.delete("/api/ingredients/{ingredient_id}", dependencies=[Admin])
    def delete_ingredient(ingredient_id: int) -> dict:
        with db.tx() as c:
            return {"result": inventory.delete_ingredient(c, ingredient_id)}

    @app.post("/api/ingredients/{ingredient_id}/entries", dependencies=[Admin], status_code=201)
    def add_entry(ingredient_id: int, body: EntryIn) -> dict:
        with db.tx() as c:
            shift = shifts.current_shift(c)
            cost = inventory.record_entry(c, ingredient_id, shift_id=shift["id"] if shift else None, **body.model_dump())
        return {"cost_mc": cost}

    @app.post("/api/ingredients/{ingredient_id}/waste", dependencies=[Admin], status_code=201)
    def add_waste(ingredient_id: int, body: WasteIn) -> dict:
        with db.tx() as c:
            shift = shifts.current_shift(c)
            inventory.record_waste(c, ingredient_id, qty=body.qty, note=body.note, shift_id=shift["id"] if shift else None)
        return {"ok": True}

    @app.post("/api/stock-counts", dependencies=[Admin], status_code=201)
    def stock_count(body: CountIn) -> dict:
        with db.tx() as c:
            return inventory.record_count(c, [(i.ingredient_id, i.counted) for i in body.items], body.note)

    # --- Turno y caja ---------------------------------------------------

    @app.post("/api/shifts/open", status_code=201)
    def open_shift(body: OpenShiftIn) -> dict:
        with db.tx() as c:
            return shifts.open_shift(c, body.opening_float_cents)

    @app.get("/api/shifts/current", dependencies=[Admin])
    def current_shift_summary() -> dict:
        with db.read() as c:
            return shifts.shift_summary(c, shifts.require_open_shift(c)["id"])

    @app.post("/api/shifts/current/close", dependencies=[Admin])
    def close_shift(body: CloseShiftIn) -> dict:
        try:
            breakdown = {int(k): v for k, v in (body.breakdown or {}).items()}
        except ValueError:
            raise DomainError("invalid_denomination", "Desglose no válido.") from None
        with db.tx() as c:
            result = shifts.close_shift(
                c, counted_cash_cents=body.counted_cash_cents, next_float_cents=body.next_float_cents, breakdown=breakdown
            )
        # El cierre ya está guardado: ni la copia ni el Excel deben deshacerlo si fallan.
        try:
            result["backup"] = backups.make()
        except Exception:
            result["backup"] = None
        result["excel_saved"] = None
        try:
            with db.read() as c:
                data = reports.shift_report(c, result["id"])
            saved = folder.save(CLOSINGS, _shift_filename(data), excel.shift_workbook(data))
            result["excel_saved"] = str(saved) if saved else None
        except Exception:
            log.exception("No se pudo guardar el Excel del cierre en la carpeta")
        return result

    @app.get("/api/shifts", dependencies=[Admin])
    def list_shifts() -> list:
        with db.read() as c:
            return reports.list_shifts(c)

    @app.get("/api/shifts/{shift_id}/excel", dependencies=[Admin])
    def shift_excel(shift_id: int) -> Response:
        with db.read() as c:
            reports.require_shift(c, shift_id)
            data = reports.shift_report(c, shift_id)
        content = excel.shift_workbook(data)  # fuera del candado: no frena las ventas
        return _download(content, _shift_filename(data), XLSX)

    @app.get("/api/reports", dependencies=[Admin])
    def period_report(date_from: str, date_to: str) -> dict:
        with db.read() as c:
            return reports.period_report(c, date_from, date_to)

    @app.get("/api/reports/excel", dependencies=[Admin])
    def period_excel(date_from: str, date_to: str) -> Response:
        with db.read() as c:
            data = reports.period_report(c, date_from, date_to)
        return _download(excel.period_workbook(data), f"CPBAR_informe_{date_from}_a_{date_to}.xlsx", XLSX)

    @app.post("/api/reports/excel/save", dependencies=[Admin])
    def period_excel_save(date_from: str, date_to: str) -> dict:
        with db.read() as c:
            data = reports.period_report(c, date_from, date_to)
        saved = folder.save(REPORTS, f"CPBAR_informe_{date_from}_a_{date_to}.xlsx", excel.period_workbook(data))
        return {"path": str(saved) if saved else None}

    @app.post("/api/shifts/{shift_id}/excel/save", dependencies=[Admin])
    def shift_excel_save(shift_id: int) -> dict:
        with db.read() as c:
            reports.require_shift(c, shift_id)
            data = reports.shift_report(c, shift_id)
        saved = folder.save(CLOSINGS, _shift_filename(data), excel.shift_workbook(data))
        return {"path": str(saved) if saved else None}

    @app.get("/api/backups", dependencies=[Admin])
    def backup_status() -> dict:
        return {**backups.status(), "export_folder": str(folder.root) if folder.root else None}

    @app.post("/api/backups", dependencies=[Admin], status_code=201)
    def backup_now() -> dict:
        return backups.make()

    @app.get("/api/backups/download", dependencies=[Admin])
    def backup_download() -> Response:
        made = backups.make(copy_to_usb=False)
        path = Path(made["file"])
        return _download(path.read_bytes(), path.name, "application/vnd.sqlite3")

    @app.post("/api/admin/start-real", dependencies=[Admin])
    def start_real(body: StartRealIn) -> dict:
        copy = reset.start_real(db, settings.backup_dir)
        return {"ok": True, "practice_copy": str(copy)}

    @app.post("/api/cash-movements", dependencies=[Admin], status_code=201)
    def cash_movement(body: CashMovementIn) -> dict:
        with db.tx() as c:
            return {"id": shifts.add_cash_movement(c, **body.model_dump())}

    # --- Ventas ---------------------------------------------------------

    @app.post("/api/sales")
    def create_sale(body: SaleIn, response: Response) -> dict:
        req = sales.SaleRequest(
            id=body.id, kind=body.kind, payment_method=body.payment_method, tendered_cents=body.tendered_cents,
            note=body.note, device_id=body.device_id, client_created_at=body.client_created_at, queued=body.queued,
            lines=[sales.LineRequest(**l.model_dump()) for l in body.lines], tab_id=body.tab_id,
        )
        with db.tx() as c:
            if body.tab_id is None:
                result = sales.create_sale(c, req)
            else:
                result = _charge_tab(c, req, body.tab_version)
        response.status_code = 200 if result["duplicate"] else 201
        return result

    def _charge_tab(c: sqlite3.Connection, req: sales.SaleRequest, version: int | None) -> dict:
        """Cobra una cuenta abierta: la venta y el cierre de la cuenta van en la misma transacción."""
        sale_id = sales.normalize_uuid(req.id)
        tab = tabs.get_tab(c, req.tab_id)
        if tab["status"] == "paid" and tab["sale_id"] == sale_id:
            return {**sales.get_sale(c, sale_id), "duplicate": True}  # reintento de un cobro ya hecho
        tab = tabs.require_open_tab(c, req.tab_id)
        if version != tab["version"]:
            raise Conflict("tab_changed", f"La cuenta de {tab['name']} ha cambiado en otra pantalla. Revísala y cobra otra vez.", tab)
        if not tab["lines"]:
            raise DomainError("empty_sale", "La cuenta está vacía.")
        req.lines = tabs.sale_lines(tab)
        if req.kind == "venta" and not req.note:
            req.note = f"Cuenta de {tab['name']}"
        result = sales.create_sale(c, req)
        tabs.mark_paid(c, tab["id"], result["id"])
        return result

    # --- Cuentas abiertas a nombre ----------------------------------------

    @app.get("/api/tabs")
    def list_tabs() -> list:
        with db.read() as c:
            return tabs.list_open(c)

    @app.post("/api/tabs", status_code=201)
    def create_tab(body: TabIn) -> dict:
        with db.tx() as c:
            return tabs.create_tab(c, body.name, [l.model_dump() for l in body.lines], body.device_id)

    @app.get("/api/tabs/{tab_id}")
    def get_tab(tab_id: int) -> dict:
        with db.read() as c:
            return tabs.get_tab(c, tab_id)

    @app.patch("/api/tabs/{tab_id}")
    def update_tab(tab_id: int, body: TabPatch) -> dict:
        lines = None if body.lines is None else [l.model_dump() for l in body.lines]
        with db.tx() as c:
            return tabs.update_tab(c, tab_id, version=body.version, lines=lines, name=body.name, device_id=body.device_id)

    @app.post("/api/tabs/{tab_id}/cancel")
    def cancel_tab(tab_id: int, body: TabCancelIn, request: Request) -> dict:
        with db.read() as c:
            has_lines = bool(tabs.require_open_tab(c, tab_id)["lines"])
        if has_lines:
            require_admin(request)  # eliminar una cuenta con consumiciones pide contraseña
        with db.tx() as c:
            return tabs.cancel_tab(c, tab_id, body.reason, body.device_id)

    @app.get("/api/sales/recent", dependencies=[Admin])
    def recent_sales(limit: int = 30) -> list:
        with db.read() as c:
            shift = shifts.require_open_shift(c)
            return sales.recent_sales(c, shift["id"], max(1, min(limit, 200)))

    @app.post("/api/voids", dependencies=[Admin])
    def void(body: VoidIn) -> dict:
        with db.tx() as c:
            return sales.void(c, request_id=body.id, sale_id=body.sale_id, reason=body.reason,
                              line_id=body.line_id, qty=body.qty)

    @app.post("/api/events/cart-line-removed", status_code=201)
    def cart_line_removed(body: CartRemovalIn) -> dict:
        with db.tx() as c:
            sales.log_cart_removal(c, body.model_dump())
        return {"ok": True}

    if settings.static_dir and Path(settings.static_dir).is_dir():
        app.mount("/", _RevalidatedStaticFiles(directory=settings.static_dir, html=True), name="static")

    return app
