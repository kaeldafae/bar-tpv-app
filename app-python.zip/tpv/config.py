"""Rutas y parámetros de arranque. Se pueden cambiar con variables de entorno."""

from __future__ import annotations

import os
import sys
from dataclasses import dataclass
from pathlib import Path


def _default_data_dir() -> Path:
    # Fuera de Documentos a propósito: si Documentos se sincroniza con OneDrive,
    # una base SQLite abierta dentro acaba dañada.
    if sys.platform == "win32":
        return Path(os.environ.get("SystemDrive", "C:") + "\\") / "BarTPV" / "datos"
    return Path.home() / ".bartpv" / "datos"


def _export_dir() -> Path | None:
    value = os.environ.get("TPV_EXPORT_DIR")
    if value == "":
        return None
    if value:
        return Path(value)
    from .carpeta import FOLDER_NAME, desktop_dir

    return desktop_dir() / FOLDER_NAME


@dataclass(frozen=True)
class Settings:
    data_dir: Path
    host: str = "127.0.0.1"
    port: int = 8765
    static_dir: Path | None = None
    # Nombres por los que se acepta que llamen al servidor. Frena el "DNS rebinding":
    # una web ajena que intente hablar con la caja a través del navegador del bar.
    allowed_hosts: tuple[str, ...] = ("127.0.0.1", "localhost")
    # Carpeta «TPV BAR» del escritorio para Excel y copias. None: no se guarda nada fuera.
    export_dir: Path | None = None

    @property
    def db_path(self) -> Path:
        return self.data_dir / "tpv.sqlite3"

    @property
    def backup_dir(self) -> Path:
        return self.data_dir.parent / "copias"

    @property
    def log_path(self) -> Path:
        return self.data_dir / "tpv.log"

    @classmethod
    def from_env(cls) -> "Settings":
        static = os.environ.get("TPV_STATIC_DIR") or str(Path(__file__).resolve().parents[2] / "frontend")
        return cls(
            data_dir=Path(os.environ.get("TPV_DATA_DIR") or _default_data_dir()),
            host=os.environ.get("TPV_HOST", "127.0.0.1"),
            port=int(os.environ.get("TPV_PORT", "8765")),
            static_dir=Path(static) if static else None,
            export_dir=_export_dir(),
            allowed_hosts=tuple(h.strip() for h in os.environ.get("TPV_ALLOWED_HOSTS", "127.0.0.1,localhost").split(",") if h.strip()),
        )
