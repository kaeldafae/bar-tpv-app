"""Carpeta «TPV BAR» del escritorio: Excel de cierres, informes y copias, a mano del dueño.

La base de datos NO va aquí: el escritorio suele sincronizarse con OneDrive y una base
SQLite abierta en una carpeta sincronizada se daña. Aquí solo van archivos terminados.
"""

from __future__ import annotations

import logging
import os
import sys
from pathlib import Path

log = logging.getLogger("tpv.carpeta")

FOLDER_NAME = "TPV BAR"
CLOSINGS = "Cierres de turno"
REPORTS = "Informes"
BACKUPS = "Copias de seguridad"

README = """CARPETA TPV BAR
================

Aquí la caja guarda sola, sin que tengas que hacer nada:

  Cierres de turno     El Excel de cada cierre (se crea al cerrar el turno).
  Informes             Los informes que descargues desde la pantalla Informes.
  Copias de seguridad  Las últimas copias de seguridad de la caja (30).

Puedes abrir, copiar o imprimir estos archivos. No hace falta borrarlos.
Si borras esta carpeta, la caja la vuelve a crear; tus ventas no se pierden,
porque los datos están guardados aparte (en el PC, en C:\\BarTPV\\datos;
en la tablet, dentro de la app Termux).

Guarda los cierres al menos 6 años (art. 30 del Código de Comercio).
"""


def desktop_dir() -> Path:
    """Escritorio real del usuario (también si se llama «Escritorio» o está en OneDrive)."""
    if sys.platform == "win32":
        try:
            import ctypes
            from ctypes import wintypes
            import uuid

            class GUID(ctypes.Structure):
                _fields_ = [("Data1", wintypes.DWORD), ("Data2", wintypes.WORD), ("Data3", wintypes.WORD), ("Data4", ctypes.c_ubyte * 8)]

            u = uuid.UUID("{B4BFCC3A-DB2C-424C-B029-7FE99A87C641}")  # FOLDERID_Desktop
            guid = GUID(u.fields[0], u.fields[1], u.fields[2], (ctypes.c_ubyte * 8).from_buffer_copy(u.bytes[8:]))
            path_ptr = ctypes.c_wchar_p()
            if ctypes.windll.shell32.SHGetKnownFolderPath(ctypes.byref(guid), 0, None, ctypes.byref(path_ptr)) == 0:
                try:
                    return Path(path_ptr.value)
                finally:
                    ctypes.windll.ole32.CoTaskMemFree(path_ptr)
        except Exception:
            log.exception("No se pudo obtener el escritorio con SHGetKnownFolderPath")
        return Path(os.environ.get("USERPROFILE", str(Path.home()))) / "Desktop"
    return Path.home() / "Desktop"


class ExportFolder:
    def __init__(self, root: Path | None) -> None:
        self.root = Path(root) if root else None

    def ensure(self) -> bool:
        if self.root is None:
            return False
        try:
            for sub in (CLOSINGS, REPORTS, BACKUPS):
                (self.root / sub).mkdir(parents=True, exist_ok=True)
            readme = self.root / "LEEME.txt"
            if not readme.exists():
                readme.write_text(README, encoding="utf-8-sig")
            return True
        except OSError:
            log.exception("No se pudo crear la carpeta %s", self.root)
            return False

    def save(self, sub: str, filename: str, content: bytes) -> Path | None:
        """Guarda un archivo terminado. Si está abierto en Excel, guarda una copia con otro nombre."""
        if not self.ensure():
            return None
        folder = self.root / sub
        stem, suffix = os.path.splitext(filename)
        for n in range(0, 20):
            target = folder / (filename if n == 0 else f"{stem} ({n + 1}){suffix}")
            tmp = target.with_name(target.name + ".tmp")
            try:
                tmp.write_bytes(content)
                os.replace(tmp, target)
                return target
            except PermissionError:
                tmp.unlink(missing_ok=True)
                continue
            except OSError:
                tmp.unlink(missing_ok=True)
                log.exception("No se pudo guardar %s", target)
                return None
        return None
