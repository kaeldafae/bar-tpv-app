"""Cierres para la app «Gestión del bar» (formato cpbar.cierre/1).

Al cerrar un turno se genera un cierre con todo lo necesario: ventas con sus
productos, cantidades, precios y forma de pago, el total vendido y el arqueo
(efectivo esperado, contado y diferencia). Se guarda en la tabla `cierres`, que
hace de cola de envío.

- Envío automático: la interfaz (js/envio.js) pide los pendientes, los manda a
  Gestión con la llave de esta caja y apunta el resultado. Si falla, se reintenta
  más tarde, esperando cada vez un poco más.
- Envío manual: los mismos cierres se descargan como archivo y se suben en Gestión.

El identificador de cada cierre se calcula a partir de la caja y del turno, así que
es siempre el mismo: Gestión lo usa para no importar nunca un cierre dos veces,
llegue por internet o por archivo, y aunque llegue repetido.
"""

from __future__ import annotations

import base64
import binascii
import json
import re
import sqlite3
import uuid
from datetime import datetime, timedelta, timezone
from typing import Any
from urllib.parse import urlparse

from . import __version__, reports
from .db import utc_now
from .errors import DomainError, NotFound
from .seed import DEMO_FLAG

FORMAT = "cpbar.cierre/1"
BUNDLE_FORMAT = "cpbar.lote/1"
CODE_PREFIX = "CPBAR1:"
# Espacio de nombres fijo para los identificadores de cierre (uuid5). No cambiar nunca.
_NAMESPACE = uuid.UUID("6f1d7c0e-3b0a-5c8e-9d42-0c5a1b2e7f10")
_TOKEN = re.compile(r"^[A-Za-z0-9_.\-]{20,200}$")
MAX_BATCH = 20
MAX_BACKOFF_MIN = 60

K_DEVICE_ID = "device.id"
K_DEVICE_NAME = "device.name"
K_ENDPOINT = "gestion.endpoint"
K_TOKEN = "gestion.token"


# --- Ajustes de la conexión ---------------------------------------------------------

def _meta(conn: sqlite3.Connection, key: str) -> str | None:
    row = conn.execute("SELECT value FROM meta WHERE key = ?", (key,)).fetchone()
    return row["value"] if row else None


def _set_meta(conn: sqlite3.Connection, key: str, value: str | None) -> None:
    if value is None:
        conn.execute("DELETE FROM meta WHERE key = ?", (key,))
    else:
        conn.execute("INSERT INTO meta (key, value) VALUES (?, ?) ON CONFLICT (key) DO UPDATE SET value = excluded.value",
                     (key, value))


def device(conn: sqlite3.Connection, default_name: str) -> dict[str, str]:
    device_id = _meta(conn, K_DEVICE_ID)
    if device_id is None:  # bases anteriores a la migración 4 nunca llegan aquí; por si acaso
        raise DomainError("no_device_id", "Esta caja no tiene identificador. Reinicia la caja.")
    return {"id": device_id, "name": _meta(conn, K_DEVICE_NAME) or default_name}


def is_demo(conn: sqlite3.Connection) -> bool:
    return conn.execute("SELECT 1 FROM meta WHERE key = ?", (DEMO_FLAG,)).fetchone() is not None


def _valid_endpoint(url: str) -> bool:
    try:
        p = urlparse(url)
    except ValueError:
        return False
    if p.scheme == "https" and p.hostname:
        return True
    # Solo para pruebas en este mismo ordenador.
    return p.scheme == "http" and p.hostname in ("127.0.0.1", "localhost")


def parse_code(code: str) -> tuple[str, str]:
    """Lee el «código de conexión» que da Gestión: CPBAR1:<base64url de {"u": url, "t": llave}>."""
    code = "".join(code.split())  # al copiar y pegar se cuelan espacios y saltos de línea
    if not code.startswith(CODE_PREFIX):
        raise DomainError("invalid_code", "Ese no es un código de conexión de Gestión. Debe empezar por CPBAR1:")
    raw = code[len(CODE_PREFIX):]
    try:
        data = json.loads(base64.urlsafe_b64decode(raw + "=" * (-len(raw) % 4)).decode("utf-8"))
    except (binascii.Error, ValueError, UnicodeDecodeError):
        raise DomainError("invalid_code", "El código de conexión está incompleto. Cópialo otra vez entero.") from None
    url, token = (data.get("u"), data.get("t")) if isinstance(data, dict) else (None, None)
    if not isinstance(url, str) or not _valid_endpoint(url):
        raise DomainError("invalid_code", "El código de conexión no tiene una dirección válida.")
    if not isinstance(token, str) or not _TOKEN.match(token):
        raise DomainError("invalid_code", "El código de conexión no tiene una llave válida.")
    return url, token


def configure(conn: sqlite3.Connection, *, code: str | None = None, device_name: str | None = None,
              disconnect: bool = False) -> None:
    if device_name is not None:
        name = " ".join(device_name.split())
        if not name:
            raise DomainError("invalid_name", "Pon un nombre a esta caja (por ejemplo: Tablet o PC).")
        _set_meta(conn, K_DEVICE_NAME, name[:40])
    if disconnect:
        _set_meta(conn, K_ENDPOINT, None)
        _set_meta(conn, K_TOKEN, None)
    elif code is not None:
        url, token = parse_code(code)
        _set_meta(conn, K_ENDPOINT, url)
        _set_meta(conn, K_TOKEN, token)
        # Con una llave nueva, los cierres que fallaron se intentan ya, sin esperar.
        conn.execute("UPDATE cierres SET last_attempt_at = NULL WHERE sent_at IS NULL")


def connection(conn: sqlite3.Connection) -> tuple[str, str] | None:
    url, token = _meta(conn, K_ENDPOINT), _meta(conn, K_TOKEN)
    return (url, token) if url and token else None


# --- El cierre --------------------------------------------------------------------

def cierre_id(device_id: str, shift: sqlite3.Row) -> str:
    return str(uuid.uuid5(_NAMESPACE, f"{device_id}:{shift['id']}:{shift['opened_at']}"))


def build(conn: sqlite3.Connection, shift_id: int, dev: dict[str, str]) -> dict[str, Any]:
    """Cierre completo de un turno cerrado, en el formato cpbar.cierre/1."""
    shift = conn.execute("SELECT * FROM shifts WHERE id = ?", (shift_id,)).fetchone()
    if shift is None:
        raise NotFound("shift_not_found", "Ese turno no existe.")
    data = reports.shift_report(conn, shift_id)  # exige que el turno esté cerrado
    s = data["summary"]

    sales: dict[str, dict[str, Any]] = {}
    heads = conn.execute(
        "SELECT id, created_at, kind, payment_method, total_cents, note FROM sales WHERE shift_id = ? ORDER BY created_at, id",
        (shift_id,),
    ).fetchall()
    for h in heads:
        sales[h["id"]] = {
            "id": h["id"], "created_at": h["created_at"], "kind": h["kind"],
            "payment_method": h["payment_method"], "total_cents": h["total_cents"],
            "voided_cents": 0, "net_cents": 0, "note": h["note"], "lines": [],
        }
    for l in data["lines"]:
        sale = sales[l["sale_id"]]
        sale["lines"].append({
            "product_id": l["product_id"], "name": l["name"], "qty": l["qty"], "voided_qty": l["voided_qty"],
            "unit_price_cents": l["unit_price_cents"], "net_cents": l["net_cents"],
        })
        sale["voided_cents"] += l["unit_price_cents"] * l["voided_qty"]
        sale["net_cents"] += l["net_cents"]

    by_method: dict[str, int] = {}
    for sale in sales.values():
        if sale["kind"] == "venta":
            by_method[sale["payment_method"]] = by_method.get(sale["payment_method"], 0) + sale["net_cents"]

    return {
        "format": FORMAT,
        "id": cierre_id(dev["id"], shift),
        "app_version": __version__,
        "device": {"id": dev["id"], "name": dev["name"]},
        "currency": "EUR",
        "shift": {
            "number": shift["id"], "business_date": shift["business_date"],
            "opened_at": shift["opened_at"], "closed_at": shift["closed_at"],
        },
        "totals": {
            "sales_count": s["sales_count"], "invitations_count": s["invitations_count"],
            "gross_cents": s["cash_sales_cents"], "voids_cents": s["voids_cents"], "net_cents": s["net_sales_cents"],
            "by_payment_method": by_method,
        },
        "cash": {
            "opening_float_cents": s["opening_float_cents"], "cash_sales_cents": s["cash_sales_cents"],
            "voids_cents": s["voids_cents"], "cash_in_cents": s["cash_in_cents"], "cash_out_cents": s["cash_out_cents"],
            "expected_cents": s["expected_cash_cents"], "counted_cents": s["counted_cash_cents"],
            "difference_cents": s["difference_cents"], "next_float_cents": s["next_float_cents"],
            "breakdown": {str(k): v for k, v in sorted(data["breakdown"].items(), reverse=True)},
        },
        "sales": list(sales.values()),
        "products": data["products"],
        "voids": [{k: v[k] for k in ("created_at", "sale_id", "name", "qty", "amount_cents", "reason")} for v in data["voids"]],
        "cash_movements": data["cash_movements"],
    }


def record(conn: sqlite3.Connection, shift_id: int, default_name: str) -> str | None:
    """Guarda en la cola el cierre de un turno cerrado. Devuelve su id (None en modo práctica)."""
    if is_demo(conn):
        return None
    row = conn.execute("SELECT id FROM cierres WHERE shift_id = ?", (shift_id,)).fetchone()
    if row:
        return row["id"]
    payload = build(conn, shift_id, device(conn, default_name))
    conn.execute(
        "INSERT INTO cierres (id, shift_id, payload, created_at) VALUES (?, ?, ?, ?)",
        (payload["id"], shift_id, json.dumps(payload, ensure_ascii=False, separators=(",", ":")), utc_now()),
    )
    return payload["id"]


def backfill(conn: sqlite3.Connection, default_name: str) -> int:
    """Crea los cierres que falten (turnos cerrados antes de esta versión o si algo falló al cerrar)."""
    if is_demo(conn):
        return 0
    missing = conn.execute(
        "SELECT id FROM shifts WHERE status = 'closed' AND id NOT IN (SELECT shift_id FROM cierres) ORDER BY id"
    ).fetchall()
    for r in missing:
        record(conn, r["id"], default_name)
    return len(missing)


# --- Cola de envío ----------------------------------------------------------------

def _parse(ts: str) -> datetime:
    return datetime.fromisoformat(ts.replace("Z", "+00:00"))


def _due(row: sqlite3.Row, now: datetime) -> bool:
    if not row["last_attempt_at"] or not row["attempts"]:
        return True
    wait = min(MAX_BACKOFF_MIN, 2 ** (row["attempts"] - 1))  # 1, 2, 4… hasta 60 minutos
    return now >= _parse(row["last_attempt_at"]) + timedelta(minutes=wait)


def batch(conn: sqlite3.Connection, *, force: bool = False, now: datetime | None = None) -> list[dict[str, Any]]:
    """Cierres pendientes que toca enviar ahora (con `force`, todos)."""
    now = now or datetime.now(timezone.utc)
    rows = conn.execute("SELECT * FROM cierres WHERE sent_at IS NULL ORDER BY created_at, shift_id").fetchall()
    due = [r for r in rows if force or _due(r, now)]
    return [{"id": r["id"], "payload": json.loads(r["payload"])} for r in due[:MAX_BATCH]]


def mark(conn: sqlite3.Connection, cierre: str, *, ok: bool, remote_status: str | None = None,
         error: str | None = None) -> dict[str, Any]:
    row = conn.execute("SELECT * FROM cierres WHERE id = ?", (cierre,)).fetchone()
    if row is None:
        raise NotFound("cierre_not_found", "Ese cierre no existe.")
    now = utc_now()
    if row["sent_at"]:
        return status_row(row)  # ya estaba enviado: nada que cambiar
    if ok:
        conn.execute("UPDATE cierres SET sent_at = ?, remote_status = ?, last_attempt_at = ?, last_error = NULL,"
                     " attempts = attempts + 1 WHERE id = ?", (now, remote_status or "recibido", now, cierre))
    else:
        conn.execute("UPDATE cierres SET attempts = attempts + 1, last_attempt_at = ?, last_error = ? WHERE id = ?",
                     (now, (error or "Error desconocido")[:300], cierre))
    return status_row(conn.execute("SELECT * FROM cierres WHERE id = ?", (cierre,)).fetchone())


def status_row(r: sqlite3.Row) -> dict[str, Any]:
    p = json.loads(r["payload"])
    return {
        "id": r["id"], "shift_id": r["shift_id"], "business_date": p["shift"]["business_date"],
        "net_cents": p["totals"]["net_cents"], "difference_cents": p["cash"]["difference_cents"],
        "created_at": r["created_at"], "sent_at": r["sent_at"], "remote_status": r["remote_status"],
        "attempts": r["attempts"], "last_attempt_at": r["last_attempt_at"], "last_error": r["last_error"],
    }


def status(conn: sqlite3.Connection, default_name: str, limit: int = 15) -> dict[str, Any]:
    pending = conn.execute(
        "SELECT COUNT(*), MIN(created_at) FROM cierres WHERE sent_at IS NULL").fetchone()
    last_sent = conn.execute("SELECT MAX(sent_at) FROM cierres").fetchone()[0]
    missing = 0 if is_demo(conn) else conn.execute(
        "SELECT COUNT(*) FROM shifts WHERE status = 'closed' AND id NOT IN (SELECT shift_id FROM cierres)").fetchone()[0]
    link = connection(conn)
    rows = conn.execute("SELECT * FROM cierres ORDER BY shift_id DESC LIMIT ?", (limit,)).fetchall()
    return {
        "configured": link is not None,
        "endpoint_host": urlparse(link[0]).hostname if link else None,
        "device": device(conn, default_name),
        "demo": is_demo(conn),
        "pending": pending[0] + missing,
        "oldest_pending_at": pending[1],
        "last_sent_at": last_sent,
        "recent": [status_row(r) for r in rows],
    }


# --- Archivos (envío manual) ---------------------------------------------------------

def file_for_shift(conn: sqlite3.Connection, shift_id: int, default_name: str) -> tuple[str, dict[str, Any]]:
    row = conn.execute("SELECT payload FROM cierres WHERE shift_id = ?", (shift_id,)).fetchone()
    if row:
        payload = json.loads(row["payload"])
    else:
        if is_demo(conn):
            raise DomainError("demo_mode", "Esta caja está en modo práctica: sus cierres no van a Gestión.")
        payload = build(conn, shift_id, device(conn, default_name))  # mismo id que tendrá al guardarse
    return _filename(payload), payload


def bundle(conn: sqlite3.Connection, *, only_pending: bool = True) -> tuple[str, dict[str, Any]]:
    where = "WHERE sent_at IS NULL" if only_pending else ""
    rows = conn.execute(f"SELECT payload FROM cierres {where} ORDER BY shift_id").fetchall()
    if not rows:
        raise DomainError("nothing_to_export", "No hay cierres pendientes de enviar.")
    cierres = [json.loads(r["payload"]) for r in rows]
    dev = cierres[-1]["device"]
    name = f"CPBAR_cierres_{_slug(dev['name'])}_{cierres[0]['shift']['business_date']}_a_{cierres[-1]['shift']['business_date']}.json"
    return name, {"format": BUNDLE_FORMAT, "device": dev, "cierres": cierres}


def _slug(text: str) -> str:
    return re.sub(r"[^A-Za-z0-9]+", "-", text).strip("-") or "caja"


def _filename(payload: dict[str, Any]) -> str:
    return (f"CPBAR_cierre_{payload['shift']['business_date']}_{_slug(payload['device']['name'])}"
            f"_n{payload['shift']['number']}.json")
