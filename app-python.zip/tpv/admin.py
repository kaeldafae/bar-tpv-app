"""Contraseña de administración guardada (solo su hash) en la tabla meta."""

from __future__ import annotations

import sqlite3

from .errors import Conflict, Unauthorized
from .inventory import log_event
from .security import hash_password, validate_new_password, verify_password

_KEY = "admin_password_hash"


def is_configured(conn: sqlite3.Connection) -> bool:
    return conn.execute("SELECT 1 FROM meta WHERE key = ?", (_KEY,)).fetchone() is not None


def setup_password(conn: sqlite3.Connection, password: str) -> None:
    if is_configured(conn):
        raise Conflict("already_configured", "La contraseña de administración ya está creada.")
    validate_new_password(password)
    conn.execute("INSERT INTO meta (key, value) VALUES (?, ?)", (_KEY, hash_password(password)))
    log_event(conn, "admin_contrasena_creada", {})


def password_hash(conn: sqlite3.Connection) -> str | None:
    row = conn.execute("SELECT value FROM meta WHERE key = ?", (_KEY,)).fetchone()
    return None if row is None else row["value"]


def check_password(conn: sqlite3.Connection, password: str) -> bool:
    stored = password_hash(conn)
    return stored is not None and verify_password(password, stored)


def change_password(conn: sqlite3.Connection, current: str, new: str) -> None:
    if not check_password(conn, current):
        raise Unauthorized("wrong_password", "La contraseña actual no es correcta.")
    validate_new_password(new)
    conn.execute("UPDATE meta SET value = ? WHERE key = ?", (hash_password(new), _KEY))
    log_event(conn, "admin_contrasena_cambiada", {})


def reset_password(conn: sqlite3.Connection, new: str) -> None:
    """Solo desde la herramienta local de recuperación (requiere estar delante del PC)."""
    validate_new_password(new)
    conn.execute(
        "INSERT INTO meta (key, value) VALUES (?, ?) ON CONFLICT (key) DO UPDATE SET value = excluded.value",
        (_KEY, hash_password(new)),
    )
    log_event(conn, "admin_contrasena_restablecida", {})
