-- Migración 002: cuentas abiertas a nombre de un cliente («la cuenta de Juan»).
-- Una cuenta abierta todavía no es una venta: guarda lo servido y se convierte en
-- venta al cobrarla. Puede seguir abierta de un turno a otro.
-- lines: JSON con las líneas [{product_id, qty, unit_price_cents, licor_option_id,
-- refresco_option_id, name}]. El precio es el del momento en que se sirvió.

CREATE TABLE open_tabs (
    id         INTEGER PRIMARY KEY,
    name       TEXT NOT NULL,
    lines      TEXT NOT NULL DEFAULT '[]',
    version    INTEGER NOT NULL DEFAULT 1,
    status     TEXT NOT NULL DEFAULT 'open' CHECK (status IN ('open', 'paid', 'cancelled')),
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    closed_at  TEXT,
    sale_id    TEXT REFERENCES sales (id),
    note       TEXT
) STRICT;
CREATE UNIQUE INDEX open_tabs_name_open ON open_tabs (name COLLATE NOCASE) WHERE status = 'open';
CREATE INDEX open_tabs_status ON open_tabs (status, updated_at);

-- Una cuenta cobrada o eliminada ya no cambia.
CREATE TRIGGER open_tabs_closed_frozen BEFORE UPDATE ON open_tabs WHEN OLD.status <> 'open'
BEGIN SELECT RAISE(ABORT, 'Una cuenta cerrada no se puede modificar'); END;
CREATE TRIGGER open_tabs_no_delete BEFORE DELETE ON open_tabs BEGIN SELECT RAISE(ABORT, 'Las cuentas no se pueden borrar'); END;
