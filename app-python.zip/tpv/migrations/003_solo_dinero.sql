-- Migración 003: la caja se centra en el dinero. El inventario (stock, insumos, recetas)
-- deja de usarse: nada se agota y vender no descuenta stock. Las tablas de inventario
-- se conservan con su historial, pero ya no intervienen.

-- Los licores de un combinado ya no necesitan botella: solo nombre y precio.
CREATE TABLE combo_options_new (
    id            INTEGER PRIMARY KEY,
    product_id    INTEGER NOT NULL REFERENCES products (id) ON DELETE CASCADE,
    grp           TEXT NOT NULL CHECK (grp IN ('licor', 'refresco')),
    label         TEXT NOT NULL,
    ingredient_id INTEGER REFERENCES ingredients (id),
    qty           INTEGER NOT NULL DEFAULT 0 CHECK (qty >= 0),
    price_cents   INTEGER CHECK (price_cents IS NULL OR price_cents >= 0),
    position      INTEGER NOT NULL DEFAULT 0,
    archived      INTEGER NOT NULL DEFAULT 0 CHECK (archived IN (0, 1)),
    CHECK ((grp = 'licor' AND price_cents IS NOT NULL) OR (grp = 'refresco' AND price_cents IS NULL))
) STRICT;
INSERT INTO combo_options_new (id, product_id, grp, label, ingredient_id, qty, price_cents, position, archived)
    SELECT id, product_id, grp, label, NULL, 0, price_cents, position, archived FROM combo_options;
DROP TABLE combo_options;
ALTER TABLE combo_options_new RENAME TO combo_options;
CREATE INDEX combo_options_product ON combo_options (product_id, grp, position);

-- Los productos dejan de descontar nada al venderse.
DELETE FROM recipe_items;
