-- Migración 001: esquema inicial del TPV.
-- Dinero: céntimos enteros. Costes unitarios: milésimas de céntimo (mc) por unidad base.
-- Cantidades de inventario: enteros en unidad base (ml, unidad o ración).
-- Fechas: texto ISO 8601 en UTC con sufijo Z. business_date: fecha local de apertura del turno.

CREATE TABLE meta (
    key   TEXT PRIMARY KEY,
    value TEXT NOT NULL
) STRICT;

CREATE TABLE categories (
    id       INTEGER PRIMARY KEY,
    name     TEXT NOT NULL,
    color    TEXT NOT NULL,
    position INTEGER NOT NULL DEFAULT 0,
    archived INTEGER NOT NULL DEFAULT 0 CHECK (archived IN (0, 1))
) STRICT;
CREATE UNIQUE INDEX categories_name_active ON categories (name COLLATE NOCASE) WHERE archived = 0;

CREATE TABLE ingredients (
    id            INTEGER PRIMARY KEY,
    name          TEXT NOT NULL,
    unit          TEXT NOT NULL CHECK (unit IN ('ml', 'ud', 'racion')),
    package_size  INTEGER NOT NULL CHECK (package_size > 0),
    package_label TEXT NOT NULL,
    stock_qty     INTEGER NOT NULL DEFAULT 0,
    cost_mc       INTEGER NOT NULL DEFAULT 0 CHECK (cost_mc >= 0),
    min_stock     INTEGER NOT NULL DEFAULT 0 CHECK (min_stock >= 0),
    archived      INTEGER NOT NULL DEFAULT 0 CHECK (archived IN (0, 1))
) STRICT;
CREATE UNIQUE INDEX ingredients_name_active ON ingredients (name COLLATE NOCASE) WHERE archived = 0;

CREATE TABLE products (
    id          INTEGER PRIMARY KEY,
    category_id INTEGER NOT NULL REFERENCES categories (id),
    name        TEXT NOT NULL,
    kind        TEXT NOT NULL DEFAULT 'simple' CHECK (kind IN ('simple', 'combinado')),
    price_cents INTEGER NOT NULL CHECK (price_cents >= 0),
    position    INTEGER NOT NULL DEFAULT 0,
    active      INTEGER NOT NULL DEFAULT 1 CHECK (active IN (0, 1)),
    archived    INTEGER NOT NULL DEFAULT 0 CHECK (archived IN (0, 1))
) STRICT;
CREATE INDEX products_category ON products (category_id, position);

-- Receta de un producto simple: qué descuenta cada unidad vendida.
CREATE TABLE recipe_items (
    product_id    INTEGER NOT NULL REFERENCES products (id) ON DELETE CASCADE,
    ingredient_id INTEGER NOT NULL REFERENCES ingredients (id),
    qty           INTEGER NOT NULL CHECK (qty > 0),
    PRIMARY KEY (product_id, ingredient_id)
) STRICT;

-- Opciones de un combinado. Grupo 'licor': fija el precio final. Grupo 'refresco': sin precio.
CREATE TABLE combo_options (
    id            INTEGER PRIMARY KEY,
    product_id    INTEGER NOT NULL REFERENCES products (id) ON DELETE CASCADE,
    grp           TEXT NOT NULL CHECK (grp IN ('licor', 'refresco')),
    label         TEXT NOT NULL,
    ingredient_id INTEGER REFERENCES ingredients (id),
    qty           INTEGER NOT NULL DEFAULT 0 CHECK (qty >= 0),
    price_cents   INTEGER CHECK (price_cents IS NULL OR price_cents >= 0),
    position      INTEGER NOT NULL DEFAULT 0,
    archived      INTEGER NOT NULL DEFAULT 0 CHECK (archived IN (0, 1)),
    CHECK ((grp = 'licor' AND price_cents IS NOT NULL AND ingredient_id IS NOT NULL AND qty > 0)
        OR (grp = 'refresco' AND price_cents IS NULL)),
    CHECK ((ingredient_id IS NULL) = (qty = 0))
) STRICT;
CREATE INDEX combo_options_product ON combo_options (product_id, grp, position);

CREATE TABLE shifts (
    id                  INTEGER PRIMARY KEY,
    business_date       TEXT NOT NULL,
    opened_at           TEXT NOT NULL,
    opening_float_cents INTEGER NOT NULL CHECK (opening_float_cents >= 0),
    status              TEXT NOT NULL DEFAULT 'open' CHECK (status IN ('open', 'closed')),
    closed_at           TEXT,
    expected_cash_cents INTEGER,
    counted_cash_cents  INTEGER,
    difference_cents    INTEGER,
    next_float_cents    INTEGER,
    cash_breakdown      TEXT,
    excel_path          TEXT
) STRICT;
CREATE UNIQUE INDEX shifts_single_open ON shifts (status) WHERE status = 'open';
CREATE INDEX shifts_business_date ON shifts (business_date);

CREATE TABLE sales (
    id                TEXT PRIMARY KEY,
    shift_id          INTEGER NOT NULL REFERENCES shifts (id),
    kind              TEXT NOT NULL CHECK (kind IN ('venta', 'invitacion')),
    payment_method    TEXT NOT NULL CHECK (payment_method IN ('efectivo', 'tarjeta', 'ninguno')),
    total_cents       INTEGER NOT NULL CHECK (total_cents >= 0),
    tendered_cents    INTEGER,
    change_cents      INTEGER,
    note              TEXT,
    device_id         TEXT NOT NULL,
    client_created_at TEXT,
    created_at        TEXT NOT NULL,
    request_hash      TEXT NOT NULL
) STRICT;
CREATE INDEX sales_shift ON sales (shift_id, created_at);

CREATE TABLE sale_lines (
    id               INTEGER PRIMARY KEY,
    sale_id          TEXT NOT NULL REFERENCES sales (id),
    product_id       INTEGER NOT NULL REFERENCES products (id),
    name             TEXT NOT NULL,
    qty              INTEGER NOT NULL CHECK (qty > 0),
    unit_price_cents INTEGER NOT NULL CHECK (unit_price_cents >= 0),
    line_total_cents INTEGER NOT NULL CHECK (line_total_cents >= 0),
    unit_cost_mc     INTEGER NOT NULL CHECK (unit_cost_mc >= 0),
    options          TEXT
) STRICT;
CREATE INDEX sale_lines_sale ON sale_lines (sale_id);
CREATE INDEX sale_lines_product ON sale_lines (product_id);

-- Lo que descontó cada unidad de una línea, para devolverlo exacto si se anula.
CREATE TABLE sale_line_usage (
    sale_line_id  INTEGER NOT NULL REFERENCES sale_lines (id),
    ingredient_id INTEGER NOT NULL REFERENCES ingredients (id),
    qty_per_unit  INTEGER NOT NULL CHECK (qty_per_unit > 0),
    unit_cost_mc  INTEGER NOT NULL CHECK (unit_cost_mc >= 0),
    PRIMARY KEY (sale_line_id, ingredient_id)
) STRICT;

CREATE TABLE voids (
    id           TEXT PRIMARY KEY,
    shift_id     INTEGER NOT NULL REFERENCES shifts (id),
    sale_id      TEXT NOT NULL REFERENCES sales (id),
    sale_line_id INTEGER NOT NULL REFERENCES sale_lines (id),
    qty          INTEGER NOT NULL CHECK (qty > 0),
    amount_cents INTEGER NOT NULL CHECK (amount_cents >= 0),
    reason       TEXT NOT NULL,
    created_at   TEXT NOT NULL
) STRICT;
CREATE INDEX voids_shift ON voids (shift_id);
CREATE INDEX voids_line ON voids (sale_line_id);

CREATE TABLE cash_movements (
    id           INTEGER PRIMARY KEY,
    shift_id     INTEGER NOT NULL REFERENCES shifts (id),
    direction    TEXT NOT NULL CHECK (direction IN ('entrada', 'salida')),
    amount_cents INTEGER NOT NULL CHECK (amount_cents > 0),
    concept      TEXT NOT NULL,
    created_at   TEXT NOT NULL
) STRICT;
CREATE INDEX cash_movements_shift ON cash_movements (shift_id);

-- Libro de movimientos de stock. ingredients.stock_qty es su suma.
CREATE TABLE stock_movements (
    id            INTEGER PRIMARY KEY,
    ingredient_id INTEGER NOT NULL REFERENCES ingredients (id),
    delta         INTEGER NOT NULL,
    kind          TEXT NOT NULL CHECK (kind IN ('venta', 'anulacion', 'compra', 'produccion', 'recuento', 'merma', 'inicial')),
    unit_cost_mc  INTEGER NOT NULL CHECK (unit_cost_mc >= 0),
    total_cents   INTEGER,
    ref           TEXT,
    note          TEXT,
    shift_id      INTEGER REFERENCES shifts (id),
    created_at    TEXT NOT NULL
) STRICT;
CREATE INDEX stock_movements_ingredient ON stock_movements (ingredient_id, created_at);
CREATE INDEX stock_movements_shift ON stock_movements (shift_id);

CREATE TABLE stock_counts (
    id         INTEGER PRIMARY KEY,
    created_at TEXT NOT NULL,
    note       TEXT
) STRICT;

CREATE TABLE stock_count_lines (
    count_id      INTEGER NOT NULL REFERENCES stock_counts (id),
    ingredient_id INTEGER NOT NULL REFERENCES ingredients (id),
    theoretical   INTEGER NOT NULL,
    counted       INTEGER NOT NULL,
    unit_cost_mc  INTEGER NOT NULL,
    PRIMARY KEY (count_id, ingredient_id)
) STRICT;

CREATE TABLE events (
    id         INTEGER PRIMARY KEY,
    created_at TEXT NOT NULL,
    type       TEXT NOT NULL,
    payload    TEXT NOT NULL
) STRICT;
CREATE INDEX events_type ON events (type, created_at);

-- Registros inalterables: ni se modifican ni se borran.
CREATE TRIGGER sales_no_update BEFORE UPDATE ON sales BEGIN SELECT RAISE(ABORT, 'Las ventas no se pueden modificar'); END;
CREATE TRIGGER sales_no_delete BEFORE DELETE ON sales BEGIN SELECT RAISE(ABORT, 'Las ventas no se pueden borrar'); END;
CREATE TRIGGER sale_lines_no_update BEFORE UPDATE ON sale_lines BEGIN SELECT RAISE(ABORT, 'Las ventas no se pueden modificar'); END;
CREATE TRIGGER sale_lines_no_delete BEFORE DELETE ON sale_lines BEGIN SELECT RAISE(ABORT, 'Las ventas no se pueden borrar'); END;
CREATE TRIGGER sale_line_usage_no_update BEFORE UPDATE ON sale_line_usage BEGIN SELECT RAISE(ABORT, 'Las ventas no se pueden modificar'); END;
CREATE TRIGGER sale_line_usage_no_delete BEFORE DELETE ON sale_line_usage BEGIN SELECT RAISE(ABORT, 'Las ventas no se pueden borrar'); END;
CREATE TRIGGER voids_no_update BEFORE UPDATE ON voids BEGIN SELECT RAISE(ABORT, 'Las anulaciones no se pueden modificar'); END;
CREATE TRIGGER voids_no_delete BEFORE DELETE ON voids BEGIN SELECT RAISE(ABORT, 'Las anulaciones no se pueden borrar'); END;
CREATE TRIGGER cash_movements_no_update BEFORE UPDATE ON cash_movements BEGIN SELECT RAISE(ABORT, 'Los movimientos de caja no se pueden modificar'); END;
CREATE TRIGGER cash_movements_no_delete BEFORE DELETE ON cash_movements BEGIN SELECT RAISE(ABORT, 'Los movimientos de caja no se pueden borrar'); END;
CREATE TRIGGER stock_movements_no_update BEFORE UPDATE ON stock_movements BEGIN SELECT RAISE(ABORT, 'Los movimientos de stock no se pueden modificar'); END;
CREATE TRIGGER stock_movements_no_delete BEFORE DELETE ON stock_movements BEGIN SELECT RAISE(ABORT, 'Los movimientos de stock no se pueden borrar'); END;
CREATE TRIGGER events_no_update BEFORE UPDATE ON events BEGIN SELECT RAISE(ABORT, 'El registro de eventos no se puede modificar'); END;
CREATE TRIGGER events_no_delete BEFORE DELETE ON events BEGIN SELECT RAISE(ABORT, 'El registro de eventos no se puede borrar'); END;

-- Un turno cerrado ya no cambia.
CREATE TRIGGER shifts_closed_frozen BEFORE UPDATE ON shifts WHEN OLD.status = 'closed'
BEGIN SELECT RAISE(ABORT, 'Un turno cerrado no se puede modificar'); END;
CREATE TRIGGER shifts_no_delete BEFORE DELETE ON shifts BEGIN SELECT RAISE(ABORT, 'Los turnos no se pueden borrar'); END;
