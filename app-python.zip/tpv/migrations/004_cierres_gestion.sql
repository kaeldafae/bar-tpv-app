-- Conexión con la app «Gestión del bar».
-- Cada turno cerrado genera un cierre (formato cpbar.cierre/1) que se guarda aquí tal
-- cual se envía. La tabla hace de cola: sent_at vacío = pendiente de enviar.

CREATE TABLE cierres (
    id              TEXT PRIMARY KEY,
    shift_id        INTEGER NOT NULL UNIQUE REFERENCES shifts (id),
    payload         TEXT NOT NULL,
    created_at      TEXT NOT NULL,
    sent_at         TEXT,
    remote_status   TEXT,
    attempts        INTEGER NOT NULL DEFAULT 0 CHECK (attempts >= 0),
    last_attempt_at TEXT,
    last_error      TEXT
) STRICT;
CREATE INDEX cierres_pending ON cierres (sent_at, created_at);

-- El contenido de un cierre no cambia nunca; solo su estado de envío.
CREATE TRIGGER cierres_frozen BEFORE UPDATE OF id, shift_id, payload, created_at ON cierres
BEGIN SELECT RAISE(ABORT, 'Un cierre no se puede modificar'); END;
CREATE TRIGGER cierres_no_delete BEFORE DELETE ON cierres
BEGIN SELECT RAISE(ABORT, 'Los cierres no se pueden borrar'); END;

-- Identificador único de esta caja (aparato). Distingue la tablet del PC en Gestión.
INSERT OR IGNORE INTO meta (key, value) VALUES ('device.id', lower(hex(randomblob(16))));
