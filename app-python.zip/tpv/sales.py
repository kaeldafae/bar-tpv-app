"""Ventas, invitaciones y anulaciones."""

from __future__ import annotations

import hashlib
import json
import sqlite3
import uuid
from dataclasses import dataclass
from typing import Any

from .catalog import get_product, options_of
from .db import utc_now
from .errors import Conflict, DomainError, NotFound
from .inventory import apply_movement, log_event
from .shifts import require_open_shift

MAX_LINE_QTY = 999


@dataclass
class LineRequest:
    product_id: int
    qty: int
    unit_price_cents: int
    licor_option_id: int | None = None
    refresco_option_id: int | None = None


@dataclass
class SaleRequest:
    id: str
    kind: str
    lines: list[LineRequest]
    payment_method: str = "efectivo"
    tendered_cents: int | None = None
    note: str | None = None
    device_id: str = "pc"
    client_created_at: str | None = None
    # True cuando la venta llega desde la cola de un dispositivo que estuvo sin conexión:
    # ya se cobró, así que se acepta con su precio.
    queued: bool = False
    # Cuenta abierta que se cobra: se cobra al precio al que se sirvió cada cosa.
    tab_id: int | None = None

    @property
    def lenient(self) -> bool:
        return self.queued or self.tab_id is not None


def normalize_uuid(value: str) -> str:
    try:
        return str(uuid.UUID(value))
    except (ValueError, AttributeError, TypeError):
        raise DomainError("invalid_id", "Identificador de venta no válido.") from None


def request_hash(req: SaleRequest) -> str:
    body = {
        "kind": req.kind,
        "payment_method": req.payment_method,
        "tendered_cents": req.tendered_cents,
        "note": req.note,
        "device_id": req.device_id,
        **({"tab_id": req.tab_id} if req.tab_id is not None else {}),
        "lines": [
            [l.product_id, l.qty, l.unit_price_cents, l.licor_option_id, l.refresco_option_id] for l in req.lines
        ],
    }
    return hashlib.sha256(json.dumps(body, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


@dataclass
class _ResolvedLine:
    product_id: int
    name: str
    qty: int
    unit_price_cents: int
    options: dict[str, Any] | None


def _resolve_line(conn: sqlite3.Connection, line: LineRequest, req: SaleRequest) -> _ResolvedLine:
    if not 1 <= line.qty <= MAX_LINE_QTY:
        raise DomainError("invalid_qty", "Cantidad no válida.")
    p = get_product(conn, line.product_id)
    if not p["active"] and not req.lenient:
        raise Conflict("product_inactive", f"«{p['name']}» no está a la venta.")

    if p["kind"] == "simple":
        if line.licor_option_id or line.refresco_option_id:
            raise DomainError("invalid_option", f"«{p['name']}» no lleva opciones.")
        return _ResolvedLine(p["id"], p["name"], line.qty, p["price_cents"], None)

    opts = {o["id"]: o for o in options_of(conn, p["id"])}
    licor = opts.get(line.licor_option_id or -1)
    refresco = opts.get(line.refresco_option_id or -1)
    if licor is None or licor["grp"] != "licor" or refresco is None or refresco["grp"] != "refresco":
        chosen = [i for i in (line.licor_option_id, line.refresco_option_id) if i]
        retired = chosen and conn.execute(
            f"SELECT 1 FROM combo_options WHERE product_id = ? AND archived = 1 AND id IN ({','.join('?' * len(chosen))})",
            [p["id"], *chosen],
        ).fetchone()
        if retired:
            raise Conflict("combo_changed", f"«{p['name']}» ha cambiado mientras la cuenta estaba abierta. Vuelve a elegir licor y refresco.")
        raise DomainError("invalid_option", "Elige licor y refresco del combinado.")
    name = f"{p['name']} {licor['label']} + {refresco['label']}"
    options = {"licor_option_id": licor["id"], "licor": licor["label"],
               "refresco_option_id": refresco["id"], "refresco": refresco["label"]}
    return _ResolvedLine(p["id"], name, line.qty, licor["price_cents"], options)


def _existing(conn: sqlite3.Connection, sale_id: str) -> sqlite3.Row | None:
    return conn.execute("SELECT * FROM sales WHERE id = ?", (sale_id,)).fetchone()


def create_sale(conn: sqlite3.Connection, req: SaleRequest) -> dict[str, Any]:
    """Registra una venta o invitación de forma atómica e idempotente.

    Reenviar la misma venta (mismo id y mismo contenido) devuelve la ya guardada
    sin duplicarla. El mismo id con otro contenido es un conflicto.
    """
    req.id = normalize_uuid(req.id)
    digest = request_hash(req)
    prev = _existing(conn, req.id)
    if prev is not None:
        if prev["request_hash"] != digest:
            raise Conflict("id_reused", "Ese identificador ya se usó para otra venta.")
        return {**get_sale(conn, req.id), "duplicate": True}

    if req.kind not in ("venta", "invitacion"):
        raise DomainError("invalid_kind", "Tipo de operación no válido.")
    if not req.lines:
        raise DomainError("empty_sale", "La cuenta está vacía.")
    shift = require_open_shift(conn)

    resolved = [_resolve_line(conn, l, req) for l in req.lines]

    # Precio: el que vio el camarero tiene que coincidir con el actual. Si un
    # administrador lo cambió mientras la cuenta estaba abierta, se avisa.
    changed = [
        {"product_id": r.product_id, "name": r.name, "visto": l.unit_price_cents, "actual": r.unit_price_cents}
        for r, l in zip(resolved, req.lines)
        if r.unit_price_cents != l.unit_price_cents
    ]
    if changed:
        if not req.lenient:
            raise Conflict("price_changed", "Ha cambiado el precio de algún producto. Revisa la cuenta.", changed)
        for r, l in zip(resolved, req.lines):
            r.unit_price_cents = l.unit_price_cents
        event = "cuenta_abierta_con_precio_antiguo" if req.tab_id is not None else "venta_en_cola_con_precio_antiguo"
        log_event(conn, event, {"sale_id": req.id, "tab_id": req.tab_id, "lineas": changed})

    if req.kind == "invitacion":
        if not (req.note or "").strip():
            raise DomainError("reason_required", "Indica el motivo de la invitación.")
        payment_method, total, tendered, change = "ninguno", 0, None, None
    else:
        if req.payment_method != "efectivo":
            raise DomainError("invalid_payment", "Por ahora solo se cobra en efectivo.")
        payment_method = "efectivo"
        total = sum(r.unit_price_cents * r.qty for r in resolved)
        tendered = total if req.tendered_cents is None else req.tendered_cents
        if tendered < total:
            raise DomainError("insufficient_cash", "El importe entregado no cubre el total.")
        change = tendered - total

    now = utc_now()
    conn.execute(
        "INSERT INTO sales (id, shift_id, kind, payment_method, total_cents, tendered_cents, change_cents, note,"
        " device_id, client_created_at, created_at, request_hash) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        (req.id, shift["id"], req.kind, payment_method, total, tendered, change, (req.note or "").strip() or None,
         req.device_id, req.client_created_at, now, digest),
    )
    for r in resolved:
        unit_price = 0 if req.kind == "invitacion" else r.unit_price_cents
        conn.execute(
            "INSERT INTO sale_lines (sale_id, product_id, name, qty, unit_price_cents, line_total_cents, unit_cost_mc, options)"
            " VALUES (?, ?, ?, ?, ?, ?, 0, ?)",
            (req.id, r.product_id, r.name, r.qty, unit_price, unit_price * r.qty,
             json.dumps(r.options, ensure_ascii=False) if r.options else None),
        )
    return {**get_sale(conn, req.id), "duplicate": False}


def get_sale(conn: sqlite3.Connection, sale_id: str) -> dict[str, Any]:
    s = conn.execute("SELECT * FROM sales WHERE id = ?", (sale_id,)).fetchone()
    if s is None:
        raise NotFound("sale_not_found", "Esa venta no existe.")
    lines = conn.execute(
        "SELECT l.*, COALESCE((SELECT SUM(v.qty) FROM voids v WHERE v.sale_line_id = l.id), 0) AS voided_qty"
        " FROM sale_lines l WHERE l.sale_id = ? ORDER BY l.id",
        (sale_id,),
    ).fetchall()
    return {
        "id": s["id"],
        "shift_id": s["shift_id"],
        "kind": s["kind"],
        "payment_method": s["payment_method"],
        "total_cents": s["total_cents"],
        "tendered_cents": s["tendered_cents"],
        "change_cents": s["change_cents"],
        "note": s["note"],
        "created_at": s["created_at"],
        "lines": [
            {
                "id": l["id"], "product_id": l["product_id"], "name": l["name"], "qty": l["qty"],
                "unit_price_cents": l["unit_price_cents"], "line_total_cents": l["line_total_cents"],
                "voided_qty": l["voided_qty"],
            }
            for l in lines
        ],
        "voided_cents": sum(l["voided_qty"] * l["unit_price_cents"] for l in lines),
    }


def recent_sales(conn: sqlite3.Connection, shift_id: int, limit: int = 30) -> list[dict[str, Any]]:
    ids = conn.execute(
        "SELECT id FROM sales WHERE shift_id = ? ORDER BY created_at DESC, rowid DESC LIMIT ?", (shift_id, limit)
    ).fetchall()
    return [get_sale(conn, r["id"]) for r in ids]


def void(
    conn: sqlite3.Connection,
    *,
    request_id: str,
    sale_id: str,
    reason: str,
    line_id: int | None = None,
    qty: int | None = None,
) -> dict[str, Any]:
    """Anula una línea (o parte) o la venta entera. Devuelve stock y resta de la caja esperada.

    Idempotente por request_id. Solo se anulan ventas del turno abierto.
    """
    request_id = normalize_uuid(request_id)
    sale_id = normalize_uuid(sale_id)
    if conn.execute("SELECT 1 FROM voids WHERE id LIKE ? LIMIT 1", (request_id + ":%",)).fetchone():
        return {**get_sale(conn, sale_id), "duplicate": True}
    reason = (reason or "").strip()
    if not reason:
        raise DomainError("reason_required", "Indica el motivo de la anulación.")
    sale = conn.execute("SELECT * FROM sales WHERE id = ?", (sale_id,)).fetchone()
    if sale is None:
        raise NotFound("sale_not_found", "Esa venta no existe.")
    shift = require_open_shift(conn)
    if sale["shift_id"] != shift["id"]:
        raise Conflict("shift_closed", "Solo se pueden anular ventas del turno abierto.")

    lines = get_sale(conn, sale_id)["lines"]
    if line_id is None:
        if qty is not None:
            raise DomainError("invalid_qty", "Para anular una cantidad, indica la línea.")
        targets = [(l, l["qty"] - l["voided_qty"]) for l in lines if l["qty"] > l["voided_qty"]]
        if not targets:
            raise Conflict("already_voided", "Esa venta ya está anulada.")
    else:
        line = next((l for l in lines if l["id"] == line_id), None)
        if line is None:
            raise NotFound("line_not_found", "Esa línea no pertenece a la venta.")
        remaining = line["qty"] - line["voided_qty"]
        qty = remaining if qty is None else qty
        if remaining <= 0:
            raise Conflict("already_voided", "Esa línea ya está anulada.")
        if not 1 <= qty <= remaining:
            raise DomainError("invalid_qty", f"Solo quedan {remaining} por anular en esa línea.")
        targets = [(line, qty)]

    now = utc_now()
    for line, n in targets:
        conn.execute(
            "INSERT INTO voids (id, shift_id, sale_id, sale_line_id, qty, amount_cents, reason, created_at)"
            " VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            (f"{request_id}:{line['id']}", shift["id"], sale_id, line["id"], n, line["unit_price_cents"] * n, reason, now),
        )
        for u in conn.execute("SELECT * FROM sale_line_usage WHERE sale_line_id = ?", (line["id"],)).fetchall():
            apply_movement(conn, u["ingredient_id"], u["qty_per_unit"] * n, "anulacion", u["unit_cost_mc"],
                           ref=request_id, note=reason, shift_id=shift["id"])
    return {**get_sale(conn, sale_id), "duplicate": False}


def log_cart_removal(conn: sqlite3.Connection, payload: dict[str, Any]) -> None:
    """Líneas quitadas de una cuenta antes de cobrar: quedan registradas como control."""
    log_event(conn, "linea_quitada_antes_de_cobrar", payload)
