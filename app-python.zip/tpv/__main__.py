"""Arranque del servidor: python -m tpv (en Windows, pythonw -m tpv para no abrir ventana)."""

from __future__ import annotations

import logging
import os
import sys
from logging.handlers import RotatingFileHandler

import uvicorn

from .api import create_app
from .backup import BackupManager
from .carpeta import BACKUPS
from .config import Settings
from .db import Database
from .seed import seed_examples


def _setup_logging(settings: Settings) -> None:
    settings.data_dir.mkdir(parents=True, exist_ok=True)
    # Con pythonw no hay consola: stdout y stderr son None y cualquier print fallaría.
    if sys.stdout is None or sys.stderr is None:
        sink = open(os.devnull, "w", encoding="utf-8")
        sys.stdout = sys.stdout or sink
        sys.stderr = sys.stderr or sink
    handler = RotatingFileHandler(settings.log_path, maxBytes=2_000_000, backupCount=3, encoding="utf-8")
    handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(name)s: %(message)s"))
    root = logging.getLogger()
    root.setLevel(logging.INFO)
    root.addHandler(handler)


def main() -> None:
    settings = Settings.from_env()
    _setup_logging(settings)
    log = logging.getLogger("tpv")
    try:
        db = Database(settings.db_path)
        with db.tx() as conn:
            seed_examples(conn)
        backups = BackupManager(db, settings.backup_dir,
                                mirror=settings.export_dir / BACKUPS if settings.export_dir else None)
        backups.start_daily()
        app = create_app(settings, db, backups)
        log.info("TPV arrancado en http://%s:%s", settings.host, settings.port)
        uvicorn.run(app, host=settings.host, port=settings.port, log_config=None, access_log=False)
    except Exception:
        log.exception("El TPV no ha podido arrancar")
        raise


if __name__ == "__main__":
    main()
