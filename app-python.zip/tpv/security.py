"""Contraseña de administración: hash scrypt, sesiones cortas y bloqueo por intentos."""

from __future__ import annotations

import base64
import hashlib
import hmac
import secrets
import threading
import time

from .errors import DomainError, TooManyAttempts, Unauthorized

_N, _R, _P = 2**14, 8, 1
MIN_PASSWORD_LENGTH = 8
SESSION_TTL_SECONDS = 5 * 60
MAX_FAILURES = 5
LOCKOUT_SECONDS = 30


def validate_new_password(password: str) -> None:
    if len(password) < MIN_PASSWORD_LENGTH:
        raise DomainError("password_too_short", f"La contraseña debe tener al menos {MIN_PASSWORD_LENGTH} caracteres.")
    if password.strip() != password:
        raise DomainError("password_spaces", "La contraseña no puede empezar ni terminar con espacios.")


def _scrypt(password: bytes, salt: bytes, n: int, r: int, p: int, dklen: int) -> bytes:
    if hasattr(hashlib, "scrypt"):
        return hashlib.scrypt(password, salt=salt, n=n, r=r, p=p, dklen=dklen)
    # En la app de la tablet (Pyodide) hashlib no trae scrypt: mismo algoritmo con pycryptodome.
    from Crypto.Protocol.KDF import scrypt

    return scrypt(password, salt, key_len=dklen, N=n, r=r, p=p)


def hash_password(password: str) -> str:
    salt = secrets.token_bytes(16)
    digest = _scrypt(password.encode("utf-8"), salt, _N, _R, _P, 32)
    return "scrypt${}${}${}${}${}".format(
        _N, _R, _P, base64.b64encode(salt).decode(), base64.b64encode(digest).decode()
    )


def verify_password(password: str, stored: str) -> bool:
    try:
        algo, n, r, p, salt_b64, digest_b64 = stored.split("$")
        if algo != "scrypt":
            return False
        salt = base64.b64decode(salt_b64)
        expected = base64.b64decode(digest_b64)
        actual = _scrypt(password.encode("utf-8"), salt, int(n), int(r), int(p), len(expected))
    except (ValueError, TypeError):
        return False
    return hmac.compare_digest(actual, expected)


class AdminSessions:
    """Sesiones en memoria: si el servidor se reinicia, hay que volver a entrar."""

    def __init__(self, clock=time.monotonic) -> None:
        self._clock = clock
        self._lock = threading.Lock()
        self._sessions: dict[str, float] = {}
        self._failures = 0
        self._locked_until = 0.0

    def check_not_locked(self) -> None:
        with self._lock:
            remaining = self._locked_until - self._clock()
            if remaining > 0:
                raise TooManyAttempts(
                    "locked", f"Demasiados intentos. Espera {int(remaining) + 1} segundos.", {"retry_after": int(remaining) + 1}
                )

    def register_failure(self) -> None:
        with self._lock:
            self._failures += 1
            if self._failures >= MAX_FAILURES:
                self._failures = 0
                self._locked_until = self._clock() + LOCKOUT_SECONDS

    def create(self) -> str:
        token = secrets.token_urlsafe(32)
        with self._lock:
            self._failures = 0
            self._sessions[token] = self._clock() + SESSION_TTL_SECONDS
        return token

    def touch(self, token: str | None) -> None:
        """Valida la sesión y alarga su caducidad (cuenta el tiempo sin uso)."""
        now = self._clock()
        with self._lock:
            expiry = self._sessions.get(token or "")
            if expiry is None or expiry <= now:
                self._sessions.pop(token or "", None)
                raise Unauthorized("admin_required", "Introduce la contraseña de administración.")
            self._sessions[token] = now + SESSION_TTL_SECONDS

    def is_active(self, token: str | None) -> bool:
        """Solo consulta: no alarga la sesión. Para el sondeo periódico de la pantalla."""
        with self._lock:
            expiry = self._sessions.get(token or "")
            return expiry is not None and expiry > self._clock()

    def revoke(self, token: str | None) -> None:
        with self._lock:
            self._sessions.pop(token or "", None)

    def revoke_all(self) -> None:
        with self._lock:
            self._sessions.clear()
