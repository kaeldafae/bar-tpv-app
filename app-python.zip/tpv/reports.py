"""Datos de informes: por turno (cierre) y por periodo. Solo lectura. Solo dinero."""

from __future__ import annotations

import json
import sqlite3
from datetime import datetime
from typing import Any

from .errors import DomainError, NotFound
from .shifts import shift_summary


def to_local(iso_utc: str | None) -> datetime | None:
    if not iso_utc:
        return None
    return datetime.fromisoformat(iso_utc.replace("Z", "+00:00")).astimezone().replace(tzinfo=None)


def _sale_rows(conn: sqlite3.Connection, where: str, params: tuple) -> list[dict[str, Any]]:
    rows = conn.execute(
        "SELECT s.id AS sale_id, s.created_at, s.kind, s.note, s.shift_id, l.id AS line_id, l.product_id, l.name,"
        " l.qty, l.unit_price_cents,"
        " COALESCE((SELECT SUM(v.qty) FROM voids v WHERE v.sale_line_id = l.id), 0) AS voided_qty"
        " FROM sales s JOIN sale_lines l ON l.sale_id = s.id"
        f" WHERE {where} ORDER BY s.created_at, l.id",
        params,
    ).fetchall()
    out = []
    for r in rows:
        net_qty = r["qty"] - r["voided_qty"]
        out.append({
            "sale_id": r["sale_id"],
            "created_at": r["created_at"],
            "kind": r["kind"],
            "note": r["note"],
            "shift_id": r["shift_id"],
            "product_id": r["product_id"],
            "name": r["name"],
            "qty": r["qty"],
            "voided_qty": r["voided_qty"],
            "net_qty": net_qty,
            "unit_price_cents": r["unit_price_cents"],
            "gross_cents": r["unit_price_cents"] * r["qty"],
            "net_cents": r["unit_price_cents"] * net_qty,
        })
    return out


def _products_from_lines(lines: list[dict[str, Any]]) -> list[dict[str, Any]]:
    agg: dict[str, dict[str, Any]] = {}
    for l in lines:
        a = agg.setdefault(l["name"], {"name": l["name"], "qty": 0, "invited_qty": 0, "revenue_cents": 0})
        if l["kind"] == "invitacion":
            a["invited_qty"] += l["net_qty"]
        else:
            a["qty"] += l["net_qty"]
            a["revenue_cents"] += l["net_cents"]
    out = [a for a in agg.values() if a["qty"] or a["invited_qty"]]
    out.sort(key=lambda a: (-a["revenue_cents"], -a["qty"], a["name"]))
    return out


def shift_report(conn: sqlite3.Connection, shift_id: int) -> dict[str, Any]:
    summary = shift_summary(conn, shift_id)
    if summary["status"] != "closed":
        raise DomainError("shift_open", "El Excel se genera al cerrar el turno.")
    lines = _sale_rows(conn, "s.shift_id = ?", (shift_id,))
    voids = [dict(r) for r in conn.execute(
        "SELECT v.created_at, v.sale_id, l.name, v.qty, v.amount_cents, v.reason, s.kind"
        " FROM voids v JOIN sale_lines l ON l.id = v.sale_line_id JOIN sales s ON s.id = v.sale_id"
        " WHERE v.shift_id = ? ORDER BY v.created_at",
        (shift_id,),
    ).fetchall()]
    cash_moves = [dict(r) for r in conn.execute(
        "SELECT created_at, direction, amount_cents, concept FROM cash_movements WHERE shift_id = ? ORDER BY created_at",
        (shift_id,),
    ).fetchall()]
    breakdown_raw = conn.execute("SELECT cash_breakdown FROM shifts WHERE id = ?", (shift_id,)).fetchone()[0]
    return {
        "summary": summary,
        "lines": lines,
        "products": _products_from_lines(lines),
        "voids": voids,
        "cash_movements": cash_moves,
        "breakdown": {int(k): v for k, v in json.loads(breakdown_raw).items()} if breakdown_raw else {},
    }


def _check_range(date_from: str, date_to: str) -> None:
    try:
        a = datetime.strptime(date_from, "%Y-%m-%d")
        b = datetime.strptime(date_to, "%Y-%m-%d")
    except ValueError:
        raise DomainError("invalid_date", "Fecha no válida.") from None
    if a > b:
        raise DomainError("invalid_range", "La fecha inicial es posterior a la final.")


def period_report(conn: sqlite3.Connection, date_from: str, date_to: str) -> dict[str, Any]:
    _check_range(date_from, date_to)
    lines = _sale_rows(conn, "s.shift_id IN (SELECT id FROM shifts WHERE business_date BETWEEN ? AND ?)",
                       (date_from, date_to))
    shifts = conn.execute(
        "SELECT id FROM shifts WHERE business_date BETWEEN ? AND ? ORDER BY business_date, id", (date_from, date_to)
    ).fetchall()
    shift_rows = [shift_summary(conn, s["id"]) for s in shifts]

    days: dict[str, dict[str, Any]] = {}
    for s in shift_rows:
        d = days.setdefault(s["business_date"], {
            "date": s["business_date"], "sales_count": 0, "invitations_count": 0, "gross_cents": 0,
            "voids_cents": 0, "net_cents": 0, "cash_in_cents": 0, "cash_out_cents": 0, "cash_difference_cents": 0,
        })
        d["sales_count"] += s["sales_count"]
        d["invitations_count"] += s["invitations_count"]
        d["gross_cents"] += s["cash_sales_cents"]
        d["voids_cents"] += s["voids_cents"]
        d["net_cents"] += s["net_sales_cents"]
        d["cash_in_cents"] += s["cash_in_cents"]
        d["cash_out_cents"] += s["cash_out_cents"]
        d["cash_difference_cents"] += s["difference_cents"] or 0
    for d in days.values():
        d["average_ticket_cents"] = round(d["net_cents"] / d["sales_count"]) if d["sales_count"] else 0

    keys = ("net_cents", "gross_cents", "voids_cents", "sales_count", "invitations_count",
            "cash_in_cents", "cash_out_cents", "cash_difference_cents")
    totals = {k: sum(d[k] for d in days.values()) for k in keys}
    totals["average_ticket_cents"] = round(totals["net_cents"] / totals["sales_count"]) if totals["sales_count"] else 0
    return {
        "from": date_from,
        "to": date_to,
        "totals": totals,
        "days": sorted(days.values(), key=lambda d: d["date"]),
        "products": _products_from_lines(lines),
        "shifts": [
            {k: s[k] for k in ("id", "business_date", "status", "opening_float_cents", "net_sales_cents",
                               "expected_cash_cents", "counted_cash_cents", "difference_cents")}
            for s in shift_rows
        ],
    }


def list_shifts(conn: sqlite3.Connection, limit: int = 60) -> list[dict[str, Any]]:
    rows = conn.execute("SELECT id FROM shifts ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
    return [shift_summary(conn, r["id"]) for r in rows]


def require_shift(conn: sqlite3.Connection, shift_id: int) -> None:
    if conn.execute("SELECT 1 FROM shifts WHERE id = ?", (shift_id,)).fetchone() is None:
        raise NotFound("shift_not_found", "Ese turno no existe.")
