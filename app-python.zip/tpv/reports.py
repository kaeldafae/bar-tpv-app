"""Datos de informes: por turno (cierre) y por periodo. Solo lectura."""

from __future__ import annotations

import json
import sqlite3
from datetime import datetime
from typing import Any

from .errors import DomainError, NotFound
from .inventory import stock_status
from .money import MC_PER_CENT, div_round, margin_pct
from .shifts import shift_summary


def to_local(iso_utc: str | None) -> datetime | None:
    if not iso_utc:
        return None
    return datetime.fromisoformat(iso_utc.replace("Z", "+00:00")).astimezone().replace(tzinfo=None)


def _sale_rows(conn: sqlite3.Connection, where: str, params: tuple) -> list[dict[str, Any]]:
    rows = conn.execute(
        "SELECT s.id AS sale_id, s.created_at, s.kind, s.note, s.shift_id, l.id AS line_id, l.product_id, l.name,"
        " l.qty, l.unit_price_cents, l.unit_cost_mc,"
        " COALESCE((SELECT SUM(v.qty) FROM voids v WHERE v.sale_line_id = l.id), 0) AS voided_qty"
        " FROM sales s JOIN sale_lines l ON l.sale_id = s.id"
        f" WHERE {where} ORDER BY s.created_at, l.id",
        params,
    ).fetchall()
    out = []
    for r in rows:
        net_qty = r["qty"] - r["voided_qty"]
        out.append({
            "sale_id": r["sale_id"],
            "created_at": r["created_at"],
            "kind": r["kind"],
            "note": r["note"],
            "shift_id": r["shift_id"],
            "product_id": r["product_id"],
            "name": r["name"],
            "qty": r["qty"],
            "voided_qty": r["voided_qty"],
            "net_qty": net_qty,
            "unit_price_cents": r["unit_price_cents"],
            "gross_cents": r["unit_price_cents"] * r["qty"],
            "net_cents": r["unit_price_cents"] * net_qty,
            "net_cost_cents": div_round(r["unit_cost_mc"] * net_qty, MC_PER_CENT),
        })
    return out


def _products_from_lines(lines: list[dict[str, Any]]) -> list[dict[str, Any]]:
    agg: dict[str, dict[str, Any]] = {}
    for l in lines:
        a = agg.setdefault(l["name"], {"name": l["name"], "qty": 0, "invited_qty": 0, "revenue_cents": 0,
                                       "cost_cents": 0, "invited_cost_cents": 0})
        if l["kind"] == "invitacion":
            a["invited_qty"] += l["net_qty"]
            a["invited_cost_cents"] += l["net_cost_cents"]
        else:
            a["qty"] += l["net_qty"]
            a["revenue_cents"] += l["net_cents"]
            a["cost_cents"] += l["net_cost_cents"]
    out = []
    for a in agg.values():
        if a["qty"] == 0 and a["invited_qty"] == 0:
            continue
        a["margin_cents"] = a["revenue_cents"] - a["cost_cents"]
        a["margin_pct"] = margin_pct(a["revenue_cents"], a["cost_cents"])
        out.append(a)
    out.sort(key=lambda a: (-a["qty"], -a["revenue_cents"], a["name"]))
    return out


def _stock_at(conn: sqlite3.Connection, moment_utc: str | None) -> list[dict[str, Any]]:
    """Stock de cada insumo en un momento dado: el actual menos lo movido después."""
    rows = conn.execute(
        "SELECT i.*, COALESCE((SELECT SUM(m.delta) FROM stock_movements m"
        " WHERE m.ingredient_id = i.id AND ? IS NOT NULL AND m.created_at > ?), 0) AS after_delta"
        " FROM ingredients i WHERE i.archived = 0 ORDER BY i.name COLLATE NOCASE",
        (moment_utc, moment_utc),
    ).fetchall()
    out = []
    for r in rows:
        qty = r["stock_qty"] - r["after_delta"]
        out.append({
            "name": r["name"], "unit": r["unit"], "package_size": r["package_size"], "package_label": r["package_label"],
            "stock_qty": qty, "min_stock": r["min_stock"], "status": stock_status(qty, r["min_stock"]),
            "package_cost_cents": div_round(r["cost_mc"] * r["package_size"], MC_PER_CENT),
            "value_cents": div_round(max(qty, 0) * r["cost_mc"], MC_PER_CENT),
        })
    return out


def shift_report(conn: sqlite3.Connection, shift_id: int) -> dict[str, Any]:
    summary = shift_summary(conn, shift_id)
    if summary["status"] != "closed":
        raise DomainError("shift_open", "El Excel se genera al cerrar el turno.")
    lines = _sale_rows(conn, "s.shift_id = ?", (shift_id,))
    voids = [dict(r) for r in conn.execute(
        "SELECT v.created_at, v.sale_id, l.name, v.qty, v.amount_cents, v.reason, s.kind"
        " FROM voids v JOIN sale_lines l ON l.id = v.sale_line_id JOIN sales s ON s.id = v.sale_id"
        " WHERE v.shift_id = ? ORDER BY v.created_at",
        (shift_id,),
    ).fetchall()]
    cash_moves = [dict(r) for r in conn.execute(
        "SELECT created_at, direction, amount_cents, concept FROM cash_movements WHERE shift_id = ? ORDER BY created_at",
        (shift_id,),
    ).fetchall()]
    breakdown_raw = conn.execute("SELECT cash_breakdown FROM shifts WHERE id = ?", (shift_id,)).fetchone()[0]
    sold = [l for l in lines if l["kind"] == "venta"]
    invited = [l for l in lines if l["kind"] == "invitacion"]
    cost = sum(l["net_cost_cents"] for l in sold)
    return {
        "summary": summary,
        "lines": lines,
        "products": _products_from_lines(lines),
        "voids": voids,
        "cash_movements": cash_moves,
        "breakdown": {int(k): v for k, v in json.loads(breakdown_raw).items()} if breakdown_raw else {},
        "inventory": _stock_at(conn, summary["closed_at"]),
        "cost_cents": cost,
        "margin_cents": summary["net_sales_cents"] - cost,
        "invited_cost_cents": sum(l["net_cost_cents"] for l in invited),
    }


def _check_range(date_from: str, date_to: str) -> None:
    try:
        a = datetime.strptime(date_from, "%Y-%m-%d")
        b = datetime.strptime(date_to, "%Y-%m-%d")
    except ValueError:
        raise DomainError("invalid_date", "Fecha no válida.") from None
    if a > b:
        raise DomainError("invalid_range", "La fecha inicial es posterior a la final.")


def period_report(conn: sqlite3.Connection, date_from: str, date_to: str) -> dict[str, Any]:
    _check_range(date_from, date_to)
    lines = _sale_rows(conn, "s.shift_id IN (SELECT id FROM shifts WHERE business_date BETWEEN ? AND ?)",
                       (date_from, date_to))
    shifts = conn.execute(
        "SELECT id FROM shifts WHERE business_date BETWEEN ? AND ? ORDER BY business_date, id", (date_from, date_to)
    ).fetchall()
    shift_rows = [shift_summary(conn, s["id"]) for s in shifts]
    by_shift_date = {s["id"]: s["business_date"] for s in shift_rows}

    days: dict[str, dict[str, Any]] = {}
    for s in shift_rows:
        d = days.setdefault(s["business_date"], {
            "date": s["business_date"], "sales_count": 0, "gross_cents": 0, "voids_cents": 0, "net_cents": 0,
            "cost_cents": 0, "invited_cost_cents": 0, "cash_difference_cents": 0,
        })
        d["sales_count"] += s["sales_count"]
        d["voids_cents"] += s["voids_cents"]
        d["cash_difference_cents"] += s["difference_cents"] or 0
    for l in lines:
        d = days[by_shift_date[l["shift_id"]]]
        if l["kind"] == "venta":
            d["gross_cents"] += l["gross_cents"]
            d["net_cents"] += l["net_cents"]
            d["cost_cents"] += l["net_cost_cents"]
        else:
            d["invited_cost_cents"] += l["net_cost_cents"]
    for d in days.values():
        d["margin_cents"] = d["net_cents"] - d["cost_cents"]
        d["margin_pct"] = margin_pct(d["net_cents"], d["cost_cents"])

    inv_diffs = [dict(r) for r in conn.execute(
        "SELECT c.created_at, i.name, i.unit, l.theoretical, l.counted, l.counted - l.theoretical AS difference,"
        " l.unit_cost_mc FROM stock_count_lines l JOIN stock_counts c ON c.id = l.count_id"
        " JOIN ingredients i ON i.id = l.ingredient_id WHERE l.counted <> l.theoretical ORDER BY c.created_at",
    ).fetchall()]
    waste = [dict(r) for r in conn.execute(
        "SELECT m.created_at, i.name, i.unit, m.delta AS difference, m.unit_cost_mc, m.note"
        " FROM stock_movements m JOIN ingredients i ON i.id = m.ingredient_id WHERE m.kind = 'merma'"
        " ORDER BY m.created_at",
    ).fetchall()]

    def in_range(row: dict[str, Any]) -> bool:
        local = to_local(row["created_at"])
        return local is not None and date_from <= local.date().isoformat() <= date_to

    inventory_changes = []
    for r in inv_diffs:
        if in_range(r):
            inventory_changes.append({**r, "kind": "recuento", "note": None})
    for r in waste:
        if in_range(r):
            inventory_changes.append({**r, "kind": "merma"})
    for r in inventory_changes:
        r["value_cents"] = div_round(r["difference"] * r["unit_cost_mc"], MC_PER_CENT)
        del r["unit_cost_mc"]
    inventory_changes.sort(key=lambda r: r["created_at"])

    totals = {
        "net_cents": sum(d["net_cents"] for d in days.values()),
        "cost_cents": sum(d["cost_cents"] for d in days.values()),
        "voids_cents": sum(d["voids_cents"] for d in days.values()),
        "invited_cost_cents": sum(d["invited_cost_cents"] for d in days.values()),
        "cash_difference_cents": sum(d["cash_difference_cents"] for d in days.values()),
        "inventory_difference_cents": sum(r["value_cents"] for r in inventory_changes),
        "sales_count": sum(d["sales_count"] for d in days.values()),
    }
    totals["margin_cents"] = totals["net_cents"] - totals["cost_cents"]
    totals["margin_pct"] = margin_pct(totals["net_cents"], totals["cost_cents"])
    return {
        "from": date_from,
        "to": date_to,
        "totals": totals,
        "days": sorted(days.values(), key=lambda d: d["date"]),
        "products": _products_from_lines(lines),
        "shifts": [
            {k: s[k] for k in ("id", "business_date", "status", "opening_float_cents", "net_sales_cents",
                               "expected_cash_cents", "counted_cash_cents", "difference_cents")}
            for s in shift_rows
        ],
        "inventory_changes": inventory_changes,
    }


def list_shifts(conn: sqlite3.Connection, limit: int = 60) -> list[dict[str, Any]]:
    rows = conn.execute("SELECT id FROM shifts ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
    return [shift_summary(conn, r["id"]) for r in rows]


def require_shift(conn: sqlite3.Connection, shift_id: int) -> None:
    if conn.execute("SELECT 1 FROM shifts WHERE id = ?", (shift_id,)).fetchone() is None:
        raise NotFound("shift_not_found", "Ese turno no existe.")
