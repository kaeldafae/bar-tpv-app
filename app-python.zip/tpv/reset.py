"""«Empezar en real»: borra la actividad de prueba y conserva el catálogo."""

from __future__ import annotations

from pathlib import Path

from .db import Database, utc_now
from .errors import Conflict
from .inventory import log_event
from .seed import DEMO_FLAG

# Tablas con la actividad de prueba, en orden de borrado (hijas antes que padres).
ACTIVITY_TABLES = (
    "open_tabs", "voids", "sale_line_usage", "sale_lines", "sales", "cash_movements",
    "stock_count_lines", "stock_counts", "stock_movements", "shifts", "events",
)


def start_real(db: Database, backup_folder: Path) -> Path:
    """Guarda una copia de la base de prueba y deja el catálogo con stock a cero.

    Los triggers que protegen las ventas se quitan y se vuelven a crear dentro de
    la misma transacción: si algo falla, no cambia nada.
    """
    backup_folder.mkdir(parents=True, exist_ok=True)
    copy = backup_folder / f"practica_antes_de_empezar_{utc_now()[:19].replace(':', '').replace('-', '')}.sqlite3"
    with db.tx() as c:
        if c.execute("SELECT 1 FROM shifts WHERE status = 'open'").fetchone():
            raise Conflict("shift_open", "Cierra el turno de prueba antes de empezar en real.")
    db.backup_to(copy)
    with db.tx() as c:
        if c.execute("SELECT 1 FROM shifts WHERE status = 'open'").fetchone():
            raise Conflict("shift_open", "Cierra el turno de prueba antes de empezar en real.")
        triggers = c.execute("SELECT name, sql FROM sqlite_master WHERE type = 'trigger'").fetchall()
        for t in triggers:
            c.execute(f'DROP TRIGGER "{t["name"]}"')
        for table in ACTIVITY_TABLES:
            c.execute(f"DELETE FROM {table}")
        c.execute("UPDATE ingredients SET stock_qty = 0")
        c.execute("DELETE FROM meta WHERE key = ?", (DEMO_FLAG,))
        for t in triggers:
            c.execute(t["sql"])
        log_event(c, "inicio_en_real", {"copia_practica": copy.name})
    return copy
