"""Secciones, productos y opciones de combinado. La caja se centra en el dinero: no hay stock."""

from __future__ import annotations

import re
import sqlite3
from typing import Any

from .errors import Conflict, DomainError, NotFound
from .inventory import log_event

HEX_COLOR = re.compile(r"^#[0-9A-Fa-f]{6}$")


# --- Secciones ---------------------------------------------------------------

def _check_category(name: str, color: str) -> str:
    name = name.strip()
    if not name:
        raise DomainError("name_required", "El nombre de la sección es obligatorio.")
    if not HEX_COLOR.match(color):
        raise DomainError("invalid_color", "Color no válido.")
    return name


def _ensure_unique_category(conn: sqlite3.Connection, name: str, exclude_id: int | None = None) -> None:
    if conn.execute(
        "SELECT 1 FROM categories WHERE archived = 0 AND name = ? COLLATE NOCASE AND id IS NOT ?", (name, exclude_id)
    ).fetchone():
        raise Conflict("duplicate_name", f"Ya existe una sección llamada «{name}».")


def create_category(conn: sqlite3.Connection, *, name: str, color: str, position: int | None = None) -> int:
    name = _check_category(name, color)
    _ensure_unique_category(conn, name)
    if position is None:
        position = conn.execute("SELECT COALESCE(MAX(position), -1) + 1 FROM categories").fetchone()[0]
    return conn.execute(
        "INSERT INTO categories (name, color, position) VALUES (?, ?, ?)", (name, color, position)
    ).lastrowid


def get_category(conn: sqlite3.Connection, category_id: int) -> sqlite3.Row:
    row = conn.execute("SELECT * FROM categories WHERE id = ? AND archived = 0", (category_id,)).fetchone()
    if row is None:
        raise NotFound("category_not_found", "Esa sección no existe.")
    return row


def update_category(conn: sqlite3.Connection, category_id: int, *, name=None, color=None, position=None) -> None:
    cur = get_category(conn, category_id)
    name = _check_category(name if name is not None else cur["name"], color if color is not None else cur["color"])
    _ensure_unique_category(conn, name, category_id)
    conn.execute(
        "UPDATE categories SET name = ?, color = ?, position = ? WHERE id = ?",
        (name, color or cur["color"], cur["position"] if position is None else position, category_id),
    )


def delete_category(conn: sqlite3.Connection, category_id: int) -> str:
    get_category(conn, category_id)
    live = conn.execute(
        "SELECT COUNT(*) FROM products WHERE category_id = ? AND archived = 0", (category_id,)
    ).fetchone()[0]
    if live:
        raise Conflict("category_not_empty", f"La sección tiene {live} producto(s). Muévelos o elimínalos primero.")
    if conn.execute("SELECT 1 FROM products WHERE category_id = ? LIMIT 1", (category_id,)).fetchone():
        conn.execute("UPDATE categories SET archived = 1 WHERE id = ?", (category_id,))
        return "archived"
    conn.execute("DELETE FROM categories WHERE id = ?", (category_id,))
    return "deleted"


# --- Productos ---------------------------------------------------------------

def get_product(conn: sqlite3.Connection, product_id: int) -> sqlite3.Row:
    row = conn.execute("SELECT * FROM products WHERE id = ? AND archived = 0", (product_id,)).fetchone()
    if row is None:
        raise NotFound("product_not_found", "Ese producto no existe.")
    return row


def _validate_options(options: list[dict[str, Any]]) -> list[dict[str, Any]]:
    clean = []
    for pos, opt in enumerate(options):
        grp = opt.get("grp")
        label = (opt.get("label") or "").strip()
        price = opt.get("price_cents")
        if grp not in ("licor", "refresco"):
            raise DomainError("invalid_option", "Grupo de opción no válido.")
        if not label:
            raise DomainError("name_required", "Cada opción necesita un nombre.")
        if grp == "licor":
            if price is None or int(price) < 0:
                raise DomainError("invalid_price", f"El licor «{label}» necesita precio final.")
            price = int(price)
        else:
            price = None
        clean.append({"grp": grp, "label": label, "price_cents": price, "position": pos})
    if not any(o["grp"] == "licor" for o in clean) or not any(o["grp"] == "refresco" for o in clean):
        raise DomainError("combo_incomplete", "Un combinado necesita al menos un licor y un refresco.")
    return clean


def _ensure_unique_product(conn: sqlite3.Connection, name: str, exclude_id: int | None = None) -> None:
    if conn.execute(
        "SELECT 1 FROM products WHERE archived = 0 AND name = ? COLLATE NOCASE AND id IS NOT ?", (name, exclude_id)
    ).fetchone():
        raise Conflict("duplicate_name", f"Ya existe un producto llamado «{name}».")


def _write_options(conn: sqlite3.Connection, product_id: int, options: list[dict[str, Any]]) -> None:
    for o in _validate_options(options):
        conn.execute(
            "INSERT INTO combo_options (product_id, grp, label, price_cents, position) VALUES (?, ?, ?, ?, ?)",
            (product_id, o["grp"], o["label"], o["price_cents"], o["position"]),
        )


def create_product(
    conn: sqlite3.Connection,
    *,
    category_id: int,
    name: str,
    price_cents: int,
    kind: str = "simple",
    options: list[dict[str, Any]] | None = None,
    position: int | None = None,
    active: bool = True,
) -> int:
    get_category(conn, category_id)
    name = name.strip()
    if not name:
        raise DomainError("name_required", "El nombre del producto es obligatorio.")
    if price_cents < 0:
        raise DomainError("invalid_price", "El precio no puede ser negativo.")
    if kind not in ("simple", "combinado"):
        raise DomainError("invalid_kind", "Tipo de producto no válido.")
    if kind == "simple" and options:
        raise DomainError("invalid_option", "Solo los combinados tienen opciones.")
    _ensure_unique_product(conn, name)
    if position is None:
        position = conn.execute(
            "SELECT COALESCE(MAX(position), -1) + 1 FROM products WHERE category_id = ?", (category_id,)
        ).fetchone()[0]
    product_id = conn.execute(
        "INSERT INTO products (category_id, name, kind, price_cents, position, active) VALUES (?, ?, ?, ?, ?, ?)",
        (category_id, name, kind, price_cents if kind == "simple" else 0, position, int(active)),
    ).lastrowid
    if kind == "combinado":
        _write_options(conn, product_id, options or [])
    return product_id


def update_product(
    conn: sqlite3.Connection,
    product_id: int,
    *,
    category_id: int | None = None,
    name: str | None = None,
    price_cents: int | None = None,
    position: int | None = None,
    active: bool | None = None,
    options: list[dict[str, Any]] | None = None,
) -> None:
    cur = get_product(conn, product_id)
    new_name = cur["name"] if name is None else name.strip()
    if not new_name:
        raise DomainError("name_required", "El nombre del producto es obligatorio.")
    _ensure_unique_product(conn, new_name, product_id)
    if category_id is not None:
        get_category(conn, category_id)
    if price_cents is not None:
        if price_cents < 0:
            raise DomainError("invalid_price", "El precio no puede ser negativo.")
        if cur["kind"] == "combinado":
            raise DomainError("invalid_price", "El precio de un combinado se fija en cada licor.")
        if price_cents != cur["price_cents"]:
            log_event(conn, "precio_cambiado", {"product_id": product_id, "name": new_name,
                                                "antes": cur["price_cents"], "despues": price_cents})
    if options is not None and cur["kind"] != "combinado":
        raise DomainError("invalid_option", "Solo los combinados tienen opciones.")
    conn.execute(
        "UPDATE products SET category_id = ?, name = ?, price_cents = ?, position = ?, active = ? WHERE id = ?",
        (
            category_id if category_id is not None else cur["category_id"],
            new_name,
            price_cents if price_cents is not None else cur["price_cents"],
            position if position is not None else cur["position"],
            int(active) if active is not None else cur["active"],
            product_id,
        ),
    )
    if options is not None:
        # Las opciones viejas se archivan, no se borran: las ventas guardan su id en el detalle.
        conn.execute("UPDATE combo_options SET archived = 1 WHERE product_id = ?", (product_id,))
        _write_options(conn, product_id, options)


def delete_product(conn: sqlite3.Connection, product_id: int) -> str:
    """Borra si nunca se vendió; si tiene ventas, lo archiva para no romper el historial."""
    p = get_product(conn, product_id)
    if conn.execute("SELECT 1 FROM sale_lines WHERE product_id = ? LIMIT 1", (product_id,)).fetchone():
        conn.execute("UPDATE products SET archived = 1, active = 0 WHERE id = ?", (product_id,))
        log_event(conn, "producto_archivado", {"product_id": product_id, "name": p["name"]})
        return "archived"
    conn.execute("DELETE FROM products WHERE id = ?", (product_id,))
    log_event(conn, "producto_eliminado", {"product_id": product_id, "name": p["name"]})
    return "deleted"


# --- Lectura -------------------------------------------------------------------

def options_of(conn: sqlite3.Connection, product_id: int) -> list[sqlite3.Row]:
    return conn.execute(
        "SELECT id, grp, label, price_cents, position FROM combo_options"
        " WHERE product_id = ? AND archived = 0 ORDER BY grp, position",
        (product_id,),
    ).fetchall()


def describe_product(conn: sqlite3.Connection, p: sqlite3.Row) -> dict[str, Any]:
    out: dict[str, Any] = {
        "id": p["id"],
        "category_id": p["category_id"],
        "name": p["name"],
        "kind": p["kind"],
        "position": p["position"],
        "active": bool(p["active"]),
        "price_cents": p["price_cents"],
    }
    if p["kind"] == "combinado":
        opts = options_of(conn, p["id"])
        out["options"] = [{"id": o["id"], "grp": o["grp"], "label": o["label"], "price_cents": o["price_cents"]} for o in opts]
        prices = [o["price_cents"] for o in opts if o["grp"] == "licor"]
        out["price_cents"] = min(prices) if prices else 0
    return out


def list_products(conn: sqlite3.Connection, *, only_active: bool) -> list[dict[str, Any]]:
    sql = (
        "SELECT p.* FROM products p JOIN categories c ON c.id = p.category_id"
        " WHERE p.archived = 0 AND c.archived = 0"
    )
    if only_active:
        sql += " AND p.active = 1"
    sql += " ORDER BY c.position, p.position, p.name"
    return [describe_product(conn, p) for p in conn.execute(sql).fetchall()]


def sale_catalog(conn: sqlite3.Connection) -> dict[str, Any]:
    categories = [
        {"id": c["id"], "name": c["name"], "color": c["color"], "position": c["position"]}
        for c in conn.execute("SELECT * FROM categories WHERE archived = 0 ORDER BY position, name").fetchall()
    ]
    products = [p for p in list_products(conn, only_active=True)
                if p["kind"] == "simple" or (any(o["grp"] == "licor" for o in p["options"])
                                             and any(o["grp"] == "refresco" for o in p["options"]))]
    return {"categories": categories, "products": products}
