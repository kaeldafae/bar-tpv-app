"""Secciones, productos, recetas, opciones de combinado y disponibilidad."""

from __future__ import annotations

import re
import sqlite3
from typing import Any

from .errors import Conflict, DomainError, NotFound
from .inventory import log_event, stock_status
from .money import MC_PER_CENT, div_round, margin_pct

HEX_COLOR = re.compile(r"^#[0-9A-Fa-f]{6}$")


# --- Secciones ---------------------------------------------------------------

def _check_category(name: str, color: str) -> str:
    name = name.strip()
    if not name:
        raise DomainError("name_required", "El nombre de la sección es obligatorio.")
    if not HEX_COLOR.match(color):
        raise DomainError("invalid_color", "Color no válido.")
    return name


def _ensure_unique_category(conn: sqlite3.Connection, name: str, exclude_id: int | None = None) -> None:
    if conn.execute(
        "SELECT 1 FROM categories WHERE archived = 0 AND name = ? COLLATE NOCASE AND id IS NOT ?", (name, exclude_id)
    ).fetchone():
        raise Conflict("duplicate_name", f"Ya existe una sección llamada «{name}».")


def create_category(conn: sqlite3.Connection, *, name: str, color: str, position: int | None = None) -> int:
    name = _check_category(name, color)
    _ensure_unique_category(conn, name)
    if position is None:
        position = conn.execute("SELECT COALESCE(MAX(position), -1) + 1 FROM categories").fetchone()[0]
    return conn.execute(
        "INSERT INTO categories (name, color, position) VALUES (?, ?, ?)", (name, color, position)
    ).lastrowid


def get_category(conn: sqlite3.Connection, category_id: int) -> sqlite3.Row:
    row = conn.execute("SELECT * FROM categories WHERE id = ? AND archived = 0", (category_id,)).fetchone()
    if row is None:
        raise NotFound("category_not_found", "Esa sección no existe.")
    return row


def update_category(conn: sqlite3.Connection, category_id: int, *, name=None, color=None, position=None) -> None:
    cur = get_category(conn, category_id)
    name = _check_category(name if name is not None else cur["name"], color if color is not None else cur["color"])
    _ensure_unique_category(conn, name, category_id)
    conn.execute(
        "UPDATE categories SET name = ?, color = ?, position = ? WHERE id = ?",
        (name, color or cur["color"], cur["position"] if position is None else position, category_id),
    )


def delete_category(conn: sqlite3.Connection, category_id: int) -> str:
    get_category(conn, category_id)
    live = conn.execute(
        "SELECT COUNT(*) FROM products WHERE category_id = ? AND archived = 0", (category_id,)
    ).fetchone()[0]
    if live:
        raise Conflict("category_not_empty", f"La sección tiene {live} producto(s). Muévelos o elimínalos primero.")
    if conn.execute("SELECT 1 FROM products WHERE category_id = ? LIMIT 1", (category_id,)).fetchone():
        conn.execute("UPDATE categories SET archived = 1 WHERE id = ?", (category_id,))
        return "archived"
    conn.execute("DELETE FROM categories WHERE id = ?", (category_id,))
    return "deleted"


# --- Productos ---------------------------------------------------------------

def get_product(conn: sqlite3.Connection, product_id: int) -> sqlite3.Row:
    row = conn.execute("SELECT * FROM products WHERE id = ? AND archived = 0", (product_id,)).fetchone()
    if row is None:
        raise NotFound("product_not_found", "Ese producto no existe.")
    return row


def _live_ingredient(conn: sqlite3.Connection, ingredient_id: int) -> sqlite3.Row:
    row = conn.execute("SELECT * FROM ingredients WHERE id = ? AND archived = 0", (ingredient_id,)).fetchone()
    if row is None:
        raise DomainError("ingredient_not_found", "La receta usa un insumo que no existe.")
    return row


def _validate_recipe(conn: sqlite3.Connection, recipe: list[dict[str, int]]) -> list[tuple[int, int]]:
    out: dict[int, int] = {}
    for item in recipe:
        ingredient_id, qty = int(item["ingredient_id"]), int(item["qty"])
        if qty <= 0:
            raise DomainError("invalid_qty", "Las cantidades de la receta deben ser mayores que cero.")
        if ingredient_id in out:
            raise DomainError("duplicate_item", "Un insumo aparece dos veces en la receta.")
        _live_ingredient(conn, ingredient_id)
        out[ingredient_id] = qty
    return list(out.items())


def _validate_options(conn: sqlite3.Connection, options: list[dict[str, Any]]) -> list[dict[str, Any]]:
    clean = []
    for pos, opt in enumerate(options):
        grp = opt.get("grp")
        label = (opt.get("label") or "").strip()
        ingredient_id = opt.get("ingredient_id")
        qty = int(opt.get("qty") or 0)
        price = opt.get("price_cents")
        if grp not in ("licor", "refresco"):
            raise DomainError("invalid_option", "Grupo de opción no válido.")
        if ingredient_id is not None:
            ing = _live_ingredient(conn, int(ingredient_id))
            if qty <= 0:
                raise DomainError("invalid_qty", f"Indica cuánto descuenta «{label or ing['name']}».")
            label = label or ing["name"]
        elif qty:
            raise DomainError("invalid_option", "Una opción sin insumo no puede descontar cantidad.")
        if not label:
            raise DomainError("name_required", "Cada opción necesita un nombre.")
        if grp == "licor":
            if ingredient_id is None:
                raise DomainError("invalid_option", f"El licor «{label}» debe indicar su botella.")
            if price is None or int(price) < 0:
                raise DomainError("invalid_price", f"El licor «{label}» necesita precio final.")
            price = int(price)
        else:
            price = None
        clean.append({"grp": grp, "label": label, "ingredient_id": ingredient_id, "qty": qty, "price_cents": price, "position": pos})
    if not any(o["grp"] == "licor" for o in clean) or not any(o["grp"] == "refresco" for o in clean):
        raise DomainError("combo_incomplete", "Un combinado necesita al menos un licor y un refresco.")
    return clean


def _ensure_unique_product(conn: sqlite3.Connection, name: str, exclude_id: int | None = None) -> None:
    if conn.execute(
        "SELECT 1 FROM products WHERE archived = 0 AND name = ? COLLATE NOCASE AND id IS NOT ?", (name, exclude_id)
    ).fetchone():
        raise Conflict("duplicate_name", f"Ya existe un producto llamado «{name}».")


def create_product(
    conn: sqlite3.Connection,
    *,
    category_id: int,
    name: str,
    price_cents: int,
    kind: str = "simple",
    recipe: list[dict[str, int]] | None = None,
    options: list[dict[str, Any]] | None = None,
    position: int | None = None,
    active: bool = True,
) -> int:
    get_category(conn, category_id)
    name = name.strip()
    if not name:
        raise DomainError("name_required", "El nombre del producto es obligatorio.")
    if price_cents < 0:
        raise DomainError("invalid_price", "El precio no puede ser negativo.")
    if kind not in ("simple", "combinado"):
        raise DomainError("invalid_kind", "Tipo de producto no válido.")
    _ensure_unique_product(conn, name)
    if position is None:
        position = conn.execute(
            "SELECT COALESCE(MAX(position), -1) + 1 FROM products WHERE category_id = ?", (category_id,)
        ).fetchone()[0]
    product_id = conn.execute(
        "INSERT INTO products (category_id, name, kind, price_cents, position, active) VALUES (?, ?, ?, ?, ?, ?)",
        (category_id, name, kind, price_cents if kind == "simple" else 0, position, int(active)),
    ).lastrowid
    _write_composition(conn, product_id, kind, recipe or [], options or [])
    return product_id


def _write_composition(conn, product_id: int, kind: str, recipe, options) -> None:
    if kind == "simple":
        if options:
            raise DomainError("invalid_option", "Solo los combinados tienen opciones.")
        for ingredient_id, qty in _validate_recipe(conn, recipe):
            conn.execute(
                "INSERT INTO recipe_items (product_id, ingredient_id, qty) VALUES (?, ?, ?)", (product_id, ingredient_id, qty)
            )
    else:
        if recipe:
            raise DomainError("invalid_recipe", "Un combinado se define por sus opciones, no por receta.")
        for o in _validate_options(conn, options):
            conn.execute(
                "INSERT INTO combo_options (product_id, grp, label, ingredient_id, qty, price_cents, position)"
                " VALUES (?, ?, ?, ?, ?, ?, ?)",
                (product_id, o["grp"], o["label"], o["ingredient_id"], o["qty"], o["price_cents"], o["position"]),
            )


def update_product(
    conn: sqlite3.Connection,
    product_id: int,
    *,
    category_id: int | None = None,
    name: str | None = None,
    price_cents: int | None = None,
    position: int | None = None,
    active: bool | None = None,
    recipe: list[dict[str, int]] | None = None,
    options: list[dict[str, Any]] | None = None,
) -> None:
    cur = get_product(conn, product_id)
    new_name = cur["name"] if name is None else name.strip()
    if not new_name:
        raise DomainError("name_required", "El nombre del producto es obligatorio.")
    _ensure_unique_product(conn, new_name, product_id)
    if category_id is not None:
        get_category(conn, category_id)
    if price_cents is not None:
        if price_cents < 0:
            raise DomainError("invalid_price", "El precio no puede ser negativo.")
        if cur["kind"] == "combinado":
            raise DomainError("invalid_price", "El precio de un combinado se fija en cada licor.")
        if price_cents != cur["price_cents"]:
            log_event(conn, "precio_cambiado", {"product_id": product_id, "name": new_name,
                                                "antes": cur["price_cents"], "despues": price_cents})
    conn.execute(
        "UPDATE products SET category_id = ?, name = ?, price_cents = ?, position = ?, active = ? WHERE id = ?",
        (
            category_id if category_id is not None else cur["category_id"],
            new_name,
            price_cents if price_cents is not None else cur["price_cents"],
            position if position is not None else cur["position"],
            int(active) if active is not None else cur["active"],
            product_id,
        ),
    )
    if cur["kind"] == "simple" and recipe is not None:
        conn.execute("DELETE FROM recipe_items WHERE product_id = ?", (product_id,))
        _write_composition(conn, product_id, "simple", recipe, [])
    if cur["kind"] == "combinado" and options is not None:
        # Las opciones viejas se archivan, no se borran: las ventas guardan su id en el detalle.
        conn.execute("UPDATE combo_options SET archived = 1 WHERE product_id = ?", (product_id,))
        _write_composition(conn, product_id, "combinado", [], options)


def delete_product(conn: sqlite3.Connection, product_id: int) -> str:
    """Borra si nunca se vendió; si tiene ventas, lo archiva para no romper el historial."""
    p = get_product(conn, product_id)
    if conn.execute("SELECT 1 FROM sale_lines WHERE product_id = ? LIMIT 1", (product_id,)).fetchone():
        conn.execute("UPDATE products SET archived = 1, active = 0 WHERE id = ?", (product_id,))
        log_event(conn, "producto_archivado", {"product_id": product_id, "name": p["name"]})
        return "archived"
    conn.execute("DELETE FROM products WHERE id = ?", (product_id,))
    log_event(conn, "producto_eliminado", {"product_id": product_id, "name": p["name"]})
    return "deleted"


# --- Composición, coste y disponibilidad ------------------------------------

def recipe_of(conn: sqlite3.Connection, product_id: int) -> list[sqlite3.Row]:
    return conn.execute(
        "SELECT r.ingredient_id, r.qty, i.name, i.unit, i.stock_qty, i.min_stock, i.cost_mc"
        " FROM recipe_items r JOIN ingredients i ON i.id = r.ingredient_id WHERE r.product_id = ?"
        " ORDER BY i.name",
        (product_id,),
    ).fetchall()


def options_of(conn: sqlite3.Connection, product_id: int) -> list[sqlite3.Row]:
    return conn.execute(
        "SELECT o.id, o.grp, o.label, o.ingredient_id, o.qty, o.price_cents, o.position,"
        " i.stock_qty, i.min_stock, i.cost_mc"
        " FROM combo_options o LEFT JOIN ingredients i ON i.id = o.ingredient_id"
        " WHERE o.product_id = ? AND o.archived = 0 ORDER BY o.grp, o.position",
        (product_id,),
    ).fetchall()


def _usage_status(items) -> str:
    """Peor estado entre los insumos usados. Sin insumos: siempre disponible."""
    worst = "ok"
    for it in items:
        if it["ingredient_id"] is None:
            continue
        if it["stock_qty"] < it["qty"]:
            return "agotado"
        if stock_status(it["stock_qty"] - it["qty"], it["min_stock"]) != "ok":
            worst = "bajo"
    return worst


def _cost_mc(items) -> int:
    return sum(it["qty"] * it["cost_mc"] for it in items if it["ingredient_id"] is not None)


def describe_product(conn: sqlite3.Connection, p: sqlite3.Row, *, with_costs: bool) -> dict[str, Any]:
    out: dict[str, Any] = {
        "id": p["id"],
        "category_id": p["category_id"],
        "name": p["name"],
        "kind": p["kind"],
        "position": p["position"],
        "active": bool(p["active"]),
    }
    if p["kind"] == "simple":
        recipe = recipe_of(conn, p["id"])
        out["price_cents"] = p["price_cents"]
        out["status"] = _usage_status(recipe)
        if with_costs:
            cost = div_round(_cost_mc(recipe), MC_PER_CENT)
            out["recipe"] = [{"ingredient_id": r["ingredient_id"], "name": r["name"], "unit": r["unit"], "qty": r["qty"]} for r in recipe]
            out["cost_cents"] = cost
            out["margin_cents"] = p["price_cents"] - cost
            out["margin_pct"] = margin_pct(p["price_cents"], cost)
    else:
        opts = options_of(conn, p["id"])
        licores = [o for o in opts if o["grp"] == "licor"]
        refrescos = [o for o in opts if o["grp"] == "refresco"]
        described = []
        for o in opts:
            d = {
                "id": o["id"], "grp": o["grp"], "label": o["label"], "price_cents": o["price_cents"],
                "status": _usage_status([o]),
            }
            if with_costs:
                d.update({"ingredient_id": o["ingredient_id"], "qty": o["qty"],
                          "cost_cents": div_round(_cost_mc([o]), MC_PER_CENT)})
            described.append(d)
        out["options"] = described
        prices = [o["price_cents"] for o in licores]
        out["price_cents"] = min(prices) if prices else 0
        statuses = {d["status"] for d in described if d["grp"] == "licor"}
        mixer_statuses = {d["status"] for d in described if d["grp"] == "refresco"}
        if statuses == {"agotado"} or mixer_statuses == {"agotado"} or not licores or not refrescos:
            out["status"] = "agotado"
        elif "bajo" in statuses | mixer_statuses:
            out["status"] = "bajo"
        else:
            out["status"] = "ok"
    return out


def list_products(conn: sqlite3.Connection, *, with_costs: bool, only_active: bool) -> list[dict[str, Any]]:
    sql = (
        "SELECT p.* FROM products p JOIN categories c ON c.id = p.category_id"
        " WHERE p.archived = 0 AND c.archived = 0"
    )
    if only_active:
        sql += " AND p.active = 1"
    sql += " ORDER BY c.position, p.position, p.name"
    return [describe_product(conn, p, with_costs=with_costs) for p in conn.execute(sql).fetchall()]


def sale_catalog(conn: sqlite3.Connection) -> dict[str, Any]:
    categories = [
        {"id": c["id"], "name": c["name"], "color": c["color"], "position": c["position"]}
        for c in conn.execute("SELECT * FROM categories WHERE archived = 0 ORDER BY position, name").fetchall()
    ]
    return {"categories": categories, "products": list_products(conn, with_costs=False, only_active=True)}
