"""Excel (.xlsx) del cierre de turno y de los informes."""

from __future__ import annotations

import io
from typing import Any, Iterable

from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

from .reports import to_local

BAR_NAME = "CP BAR"
EUR = '#,##0.00 "€";[Red]-#,##0.00 "€"'
PCT = '0.0" %"'
DATETIME = "dd/mm/yyyy hh:mm"
HEADER_FILL = PatternFill("solid", fgColor="1F2937")
HEADER_FONT = Font(bold=True, color="FFFFFF")
TITLE_FONT = Font(bold=True, size=14)
BOLD = Font(bold=True)

UNIT_LABEL = {"ml": "cl", "ud": "ud", "racion": "raciones"}


def _euros(cents: int | None) -> float | None:
    return None if cents is None else cents / 100


def _qty_display(qty: int, unit: str) -> float:
    return qty / 10 if unit == "ml" else qty




def _put(ws, row: int, col: int, value: Any, fmt: str | None = None, font: Font | None = None):
    cell = ws.cell(row=row, column=col, value=value)
    # openpyxl convierte en fórmula cualquier texto que empiece por "=": se fuerza a texto.
    if isinstance(value, str) and value.startswith("="):
        cell.data_type = "s"
    if fmt:
        cell.number_format = fmt
    if font:
        cell.font = font
    return cell


def _table(ws, start_row: int, headers: list[tuple[str, str | None, int]], rows: Iterable[list[Any]]) -> int:
    """Escribe una tabla con cabecera. headers: (título, formato, ancho). Devuelve la fila siguiente."""
    for col, (title, _, width) in enumerate(headers, start=1):
        c = _put(ws, start_row, col, title, font=HEADER_FONT)
        c.fill = HEADER_FILL
        c.alignment = Alignment(vertical="center", wrap_text=True)
        letter = get_column_letter(col)
        ws.column_dimensions[letter].width = max(ws.column_dimensions[letter].width or 0, width)
    r = start_row + 1
    for values in rows:
        for col, value in enumerate(values, start=1):
            _put(ws, r, col, value, headers[col - 1][1])
        r += 1
    ws.freeze_panes = ws.cell(row=start_row + 1, column=1)
    return r


def _kv(ws, row: int, label: str, value: Any, fmt: str | None = None, bold: bool = False) -> int:
    _put(ws, row, 1, label, font=BOLD if bold else None)
    _put(ws, row, 2, value, fmt, font=BOLD if bold else None)
    return row + 1


def _to_bytes(wb: Workbook) -> bytes:
    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()


def shift_workbook(data: dict[str, Any]) -> bytes:
    s = data["summary"]
    wb = Workbook()

    ws = wb.active
    ws.title = "Resumen"
    ws.column_dimensions["A"].width = 34
    ws.column_dimensions["B"].width = 22
    _put(ws, 1, 1, f"{BAR_NAME} · Cierre de turno {s['business_date']}", font=TITLE_FONT)
    r = 3
    r = _kv(ws, r, "Turno nº", s["id"])
    r = _kv(ws, r, "Apertura", to_local(s["opened_at"]), DATETIME)
    r = _kv(ws, r, "Cierre", to_local(s["closed_at"]), DATETIME)
    r += 1
    r = _kv(ws, r, "Fondo de caja inicial", _euros(s["opening_float_cents"]), EUR)
    r = _kv(ws, r, "Ventas en efectivo", _euros(s["cash_sales_cents"]), EUR)
    r = _kv(ws, r, "Anulaciones", _euros(-s["voids_cents"]), EUR)
    r = _kv(ws, r, "Ventas netas", _euros(s["net_sales_cents"]), EUR, bold=True)
    r = _kv(ws, r, "Entradas de caja", _euros(s["cash_in_cents"]), EUR)
    r = _kv(ws, r, "Salidas de caja", _euros(-s["cash_out_cents"]), EUR)
    r += 1
    r = _kv(ws, r, "Efectivo esperado", _euros(s["expected_cash_cents"]), EUR, bold=True)
    r = _kv(ws, r, "Efectivo contado", _euros(s["counted_cash_cents"]), EUR, bold=True)
    r = _kv(ws, r, "Diferencia (contado − esperado)", _euros(s["difference_cents"]), EUR, bold=True)
    r = _kv(ws, r, "Fondo que queda para el siguiente turno", _euros(s["next_float_cents"]), EUR)
    r += 1
    r = _kv(ws, r, "Número de ventas", s["sales_count"])
    r = _kv(ws, r, "Coste de lo vendido", _euros(data["cost_cents"]), EUR)
    r = _kv(ws, r, "Margen bruto", _euros(data["margin_cents"]), EUR, bold=True)
    r = _kv(ws, r, "Invitaciones (número)", s["invitations_count"])
    r = _kv(ws, r, "Invitaciones (coste)", _euros(data["invited_cost_cents"]), EUR)

    if data["cash_movements"]:
        r += 1
        _put(ws, r, 1, "Movimientos de caja", font=BOLD)
        r = _table(ws, r + 1, [("Hora", DATETIME, 34), ("Tipo", None, 22), ("Importe", EUR, 14), ("Concepto", None, 40)], [
            [to_local(m["created_at"]), m["direction"], _euros(m["amount_cents"] if m["direction"] == "entrada" else -m["amount_cents"]), m["concept"]]
            for m in data["cash_movements"]
        ])
    if data["breakdown"]:
        r += 1
        _put(ws, r, 1, "Desglose del efectivo contado", font=BOLD)
        r = _table(ws, r + 1, [("Billete / moneda", EUR, 34), ("Cantidad", None, 22), ("Importe", EUR, 14)], [
            [_euros(d), n, _euros(d * n)] for d, n in sorted(data["breakdown"].items(), reverse=True) if n
        ])
    ws.freeze_panes = None

    ws = wb.create_sheet("Ventas")
    _table(ws, 1, [
        ("Hora", DATETIME, 17), ("Venta", None, 11), ("Tipo", None, 11), ("Producto", None, 38), ("Cantidad", None, 10),
        ("Precio ud.", EUR, 12), ("Importe", EUR, 12), ("Anuladas", None, 10), ("Importe neto", EUR, 13), ("Nota", None, 30),
    ], [
        [to_local(l["created_at"]), l["sale_id"][:8], "Invitación" if l["kind"] == "invitacion" else "Venta", l["name"],
         l["qty"], _euros(l["unit_price_cents"]), _euros(l["gross_cents"]), l["voided_qty"] or None,
         _euros(l["net_cents"]), l["note"]]
        for l in data["lines"]
    ])

    ws = wb.create_sheet("Productos vendidos")
    _table(ws, 1, [
        ("Producto", None, 38), ("Uds vendidas", None, 13), ("Importe", EUR, 13), ("Coste", EUR, 12),
        ("Margen", EUR, 12), ("Margen %", PCT, 11), ("Uds invitadas", None, 13), ("Coste invitaciones", EUR, 17),
    ], [
        [p["name"], p["qty"], _euros(p["revenue_cents"]), _euros(p["cost_cents"]), _euros(p["margin_cents"]),
         p["margin_pct"], p["invited_qty"] or None, _euros(p["invited_cost_cents"]) if p["invited_qty"] else None]
        for p in data["products"]
    ])

    ws = wb.create_sheet("Inventario al cierre")
    status_label = {"ok": "Bien", "bajo": "Bajo mínimo", "agotado": "AGOTADO"}
    _table(ws, 1, [
        ("Insumo", None, 32), ("Stock", "0.##", 10), ("Unidad", None, 10), ("Envases", "0.00", 10), ("Envase", None, 16),
        ("Mínimo", "0.##", 10), ("Estado", None, 14), ("Coste envase", EUR, 13), ("Valor del stock", EUR, 15),
    ], [
        [i["name"], _qty_display(i["stock_qty"], i["unit"]), UNIT_LABEL[i["unit"]], i["stock_qty"] / i["package_size"],
         i["package_label"], _qty_display(i["min_stock"], i["unit"]), status_label[i["status"]],
         _euros(i["package_cost_cents"]), _euros(i["value_cents"])]
        for i in data["inventory"]
    ])

    ws = wb.create_sheet("Anulaciones")
    _table(ws, 1, [
        ("Hora", DATETIME, 17), ("Venta", None, 11), ("Producto", None, 38), ("Uds", None, 8), ("Importe", EUR, 12),
        ("Motivo", None, 40),
    ], [
        [to_local(v["created_at"]), v["sale_id"][:8], v["name"], v["qty"], _euros(v["amount_cents"]), v["reason"]]
        for v in data["voids"]
    ])
    return _to_bytes(wb)


def period_workbook(data: dict[str, Any]) -> bytes:
    t = data["totals"]
    wb = Workbook()
    ws = wb.active
    ws.title = "Resumen"
    ws.column_dimensions["A"].width = 38
    ws.column_dimensions["B"].width = 18
    _put(ws, 1, 1, f"{BAR_NAME} · Informe del {data['from']} al {data['to']}", font=TITLE_FONT)
    r = 3
    r = _kv(ws, r, "Ventas netas", _euros(t["net_cents"]), EUR, bold=True)
    r = _kv(ws, r, "Coste de lo vendido", _euros(t["cost_cents"]), EUR)
    r = _kv(ws, r, "Margen real", _euros(t["margin_cents"]), EUR, bold=True)
    r = _kv(ws, r, "Margen %", t["margin_pct"], PCT)
    r = _kv(ws, r, "Número de ventas", t["sales_count"])
    r = _kv(ws, r, "Anulaciones", _euros(t["voids_cents"]), EUR)
    r = _kv(ws, r, "Invitaciones (coste)", _euros(t["invited_cost_cents"]), EUR)
    r = _kv(ws, r, "Diferencias de caja", _euros(t["cash_difference_cents"]), EUR)
    r = _kv(ws, r, "Diferencias de inventario (valor)", _euros(t["inventory_difference_cents"]), EUR)

    ws = wb.create_sheet("Por día")
    _table(ws, 1, [
        ("Fecha", None, 12), ("Ventas", None, 9), ("Importe neto", EUR, 14), ("Anulado", EUR, 12), ("Coste", EUR, 12),
        ("Margen", EUR, 12), ("Margen %", PCT, 10), ("Invitaciones (coste)", EUR, 19), ("Diferencia de caja", EUR, 18),
    ], [
        [d["date"], d["sales_count"], _euros(d["net_cents"]), _euros(d["voids_cents"]), _euros(d["cost_cents"]),
         _euros(d["margin_cents"]), d["margin_pct"], _euros(d["invited_cost_cents"]), _euros(d["cash_difference_cents"])]
        for d in data["days"]
    ])

    ws = wb.create_sheet("Por producto")
    _table(ws, 1, [
        ("Producto", None, 38), ("Uds vendidas", None, 13), ("Importe", EUR, 13), ("Coste", EUR, 12), ("Margen", EUR, 12),
        ("Margen %", PCT, 11), ("Uds invitadas", None, 13),
    ], [
        [p["name"], p["qty"], _euros(p["revenue_cents"]), _euros(p["cost_cents"]), _euros(p["margin_cents"]),
         p["margin_pct"], p["invited_qty"] or None]
        for p in data["products"]
    ])

    ws = wb.create_sheet("Caja por turno")
    _table(ws, 1, [
        ("Turno", None, 8), ("Fecha", None, 12), ("Estado", None, 10), ("Fondo", EUR, 12), ("Ventas netas", EUR, 14),
        ("Esperado", EUR, 12), ("Contado", EUR, 12), ("Diferencia", EUR, 12),
    ], [
        [s["id"], s["business_date"], "Cerrado" if s["status"] == "closed" else "Abierto", _euros(s["opening_float_cents"]),
         _euros(s["net_sales_cents"]), _euros(s["expected_cash_cents"]), _euros(s["counted_cash_cents"]),
         _euros(s["difference_cents"])]
        for s in data["shifts"]
    ])

    ws = wb.create_sheet("Diferencias inventario")
    _table(ws, 1, [
        ("Fecha", DATETIME, 17), ("Tipo", None, 11), ("Insumo", None, 32), ("Diferencia", "0.##", 12), ("Unidad", None, 10),
        ("Valor", EUR, 12), ("Nota", None, 30),
    ], [
        [to_local(c["created_at"]), c["kind"], c["name"], _qty_display(c["difference"], c["unit"]), UNIT_LABEL[c["unit"]],
         _euros(c["value_cents"]), c.get("note")]
        for c in data["inventory_changes"]
    ])
    return _to_bytes(wb)
