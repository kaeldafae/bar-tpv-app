"""Turnos de caja: apertura, movimientos de efectivo y cierre con arqueo."""

from __future__ import annotations

import json
import sqlite3
from typing import Any

from .db import local_today, utc_now
from .errors import Conflict, DomainError, NotFound
from .inventory import log_event

DEFAULT_FLOAT_CENTS = 25000
# Billetes y monedas en euros, en céntimos.
DENOMINATIONS = (50000, 20000, 10000, 5000, 2000, 1000, 500, 200, 100, 50, 20, 10, 5, 2, 1)


def current_shift(conn: sqlite3.Connection) -> sqlite3.Row | None:
    return conn.execute("SELECT * FROM shifts WHERE status = 'open'").fetchone()


def require_open_shift(conn: sqlite3.Connection) -> sqlite3.Row:
    shift = current_shift(conn)
    if shift is None:
        raise Conflict("no_open_shift", "No hay turno abierto. Abre el turno para empezar a vender.")
    return shift


def suggested_float(conn: sqlite3.Connection) -> int:
    row = conn.execute(
        "SELECT next_float_cents FROM shifts WHERE status = 'closed' ORDER BY closed_at DESC LIMIT 1"
    ).fetchone()
    if row is None or row["next_float_cents"] is None:
        return DEFAULT_FLOAT_CENTS
    return row["next_float_cents"]


def open_shift(conn: sqlite3.Connection, opening_float_cents: int) -> dict[str, Any]:
    if opening_float_cents < 0:
        raise DomainError("invalid_amount", "El fondo de caja no puede ser negativo.")
    if current_shift(conn) is not None:
        raise Conflict("shift_already_open", "Ya hay un turno abierto.")
    expected = suggested_float(conn)
    shift_id = conn.execute(
        "INSERT INTO shifts (business_date, opened_at, opening_float_cents) VALUES (?, ?, ?)",
        (local_today(), utc_now(), opening_float_cents),
    ).lastrowid
    if opening_float_cents != expected:
        log_event(conn, "fondo_distinto_al_previsto",
                  {"shift_id": shift_id, "previsto": expected, "contado": opening_float_cents})
    return shift_summary(conn, shift_id)


def add_cash_movement(conn: sqlite3.Connection, *, direction: str, amount_cents: int, concept: str) -> int:
    if direction not in ("entrada", "salida"):
        raise DomainError("invalid_direction", "Indica si el dinero entra o sale.")
    if amount_cents <= 0:
        raise DomainError("invalid_amount", "El importe debe ser mayor que cero.")
    concept = concept.strip()
    if not concept:
        raise DomainError("reason_required", "Indica el concepto.")
    shift = require_open_shift(conn)
    return conn.execute(
        "INSERT INTO cash_movements (shift_id, direction, amount_cents, concept, created_at) VALUES (?, ?, ?, ?, ?)",
        (shift["id"], direction, amount_cents, concept, utc_now()),
    ).lastrowid


def shift_summary(conn: sqlite3.Connection, shift_id: int) -> dict[str, Any]:
    s = conn.execute("SELECT * FROM shifts WHERE id = ?", (shift_id,)).fetchone()
    if s is None:
        raise NotFound("shift_not_found", "Ese turno no existe.")
    q = lambda sql: conn.execute(sql, (shift_id,)).fetchone()[0]  # noqa: E731
    cash_sales = q("SELECT COALESCE(SUM(total_cents), 0) FROM sales WHERE shift_id = ? AND kind = 'venta' AND payment_method = 'efectivo'")
    cash_voids = q(
        "SELECT COALESCE(SUM(v.amount_cents), 0) FROM voids v JOIN sales s ON s.id = v.sale_id"
        " WHERE v.shift_id = ? AND s.kind = 'venta' AND s.payment_method = 'efectivo'"
    )
    cash_in = q("SELECT COALESCE(SUM(amount_cents), 0) FROM cash_movements WHERE shift_id = ? AND direction = 'entrada'")
    cash_out = q("SELECT COALESCE(SUM(amount_cents), 0) FROM cash_movements WHERE shift_id = ? AND direction = 'salida'")
    expected = s["opening_float_cents"] + cash_sales - cash_voids + cash_in - cash_out
    return {
        "id": s["id"],
        "status": s["status"],
        "business_date": s["business_date"],
        "opened_at": s["opened_at"],
        "closed_at": s["closed_at"],
        "opening_float_cents": s["opening_float_cents"],
        "sales_count": q("SELECT COUNT(*) FROM sales WHERE shift_id = ? AND kind = 'venta'"),
        "invitations_count": q("SELECT COUNT(*) FROM sales WHERE shift_id = ? AND kind = 'invitacion'"),
        "cash_sales_cents": cash_sales,
        "voids_cents": cash_voids,
        "net_sales_cents": cash_sales - cash_voids,
        "cash_in_cents": cash_in,
        "cash_out_cents": cash_out,
        "expected_cash_cents": expected if s["status"] == "open" else s["expected_cash_cents"],
        "counted_cash_cents": s["counted_cash_cents"],
        "difference_cents": s["difference_cents"],
        "next_float_cents": s["next_float_cents"],
        "excel_path": s["excel_path"],
    }


def breakdown_total(breakdown: dict[int, int]) -> int:
    total = 0
    for denom, count in breakdown.items():
        if denom not in DENOMINATIONS:
            raise DomainError("invalid_denomination", f"Billete o moneda no válido: {denom}.")
        if count < 0:
            raise DomainError("invalid_qty", "Las cantidades del desglose no pueden ser negativas.")
        total += denom * count
    return total


def close_shift(
    conn: sqlite3.Connection,
    *,
    counted_cash_cents: int,
    next_float_cents: int,
    breakdown: dict[int, int] | None = None,
    excel_path: str | None = None,
) -> dict[str, Any]:
    shift = require_open_shift(conn)
    if counted_cash_cents < 0 or next_float_cents < 0:
        raise DomainError("invalid_amount", "Los importes no pueden ser negativos.")
    if breakdown:
        total = breakdown_total(breakdown)
        if total != counted_cash_cents:
            raise DomainError("breakdown_mismatch", "El desglose no suma lo contado.")
    summary = shift_summary(conn, shift["id"])
    expected = summary["expected_cash_cents"]
    conn.execute(
        "UPDATE shifts SET status = 'closed', closed_at = ?, expected_cash_cents = ?, counted_cash_cents = ?,"
        " difference_cents = ?, next_float_cents = ?, cash_breakdown = ?, excel_path = ? WHERE id = ?",
        (utc_now(), expected, counted_cash_cents, counted_cash_cents - expected, next_float_cents,
         json.dumps({str(k): v for k, v in sorted(breakdown.items(), reverse=True)}) if breakdown else None,
         excel_path, shift["id"]),
    )
    return shift_summary(conn, shift["id"])
