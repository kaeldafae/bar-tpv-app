"""La caja dentro del navegador (app de la tablet, con Pyodide).

En la tablet no hay servidor: la interfaz llama a la misma API, pero las peticiones
no salen a la red. `pwa/boot.js` las entrega a `handle()`, que ejecuta la aplicación
FastAPI de siempre dentro de la página. La base de datos vive en el sistema de
archivos del navegador (IndexedDB) y `boot.js` la guarda tras cada operación.
"""

from __future__ import annotations

import asyncio
import logging
import sqlite3
from pathlib import Path
from typing import Any

import anyio.to_thread

from . import reports
from .api import _shift_filename, create_app
from .backup import BackupManager
from .config import Settings
from .db import Database, bundled_migrations
from .errors import DomainError
from .excel import shift_workbook
from .seed import seed_examples

log = logging.getLogger("tpv.web")

HOST = "127.0.0.1"


async def _run_sync_inline(func, *args, abandon_on_cancel=False, cancellable=None, limiter=None):
    # En el navegador no hay hilos: las rutas síncronas de FastAPI se ejecutan directamente.
    return func(*args)


anyio.to_thread.run_sync = _run_sync_inline

_state: dict[str, Any] = {}


def start(data_dir: str = "/data") -> None:
    """Abre (o crea) la base de datos y prepara la aplicación."""
    settings = Settings(data_dir=Path(data_dir), static_dir=None, export_dir=None, allowed_hosts=(HOST,))
    db = Database(settings.db_path, journal_mode="DELETE")
    with db.tx() as conn:
        seed_examples(conn)
    backups = BackupManager(db, Path("/tmp/copias"), drives=lambda: [])
    _state.update(settings=settings, db=db, app=create_app(settings, db, backups))


def _db() -> Database:
    return _state["db"]


async def handle(method: str, path: str, query: str, headers: list, body: bytes | None) -> dict:
    """Atiende una petición de la interfaz como lo haría el servidor."""
    if hasattr(headers, "to_py"):  # llegan desde JavaScript
        headers = headers.to_py()
    if hasattr(body, "to_bytes"):
        body = body.to_bytes()
    raw_headers = [(str(k).lower().encode("latin-1"), str(v).encode("latin-1")) for k, v in headers
                   if str(k).lower() != "host"]
    raw_headers.append((b"host", HOST.encode()))
    scope = {
        "type": "http", "asgi": {"version": "3.0"}, "http_version": "1.1", "method": method.upper(),
        "scheme": "http", "path": path, "raw_path": path.encode(), "query_string": query.encode(),
        "root_path": "", "headers": raw_headers, "client": (HOST, 0), "server": (HOST, 80),
    }
    delivered = False

    async def receive() -> dict:
        nonlocal delivered
        if not delivered:
            delivered = True
            return {"type": "http.request", "body": bytes(body or b""), "more_body": False}
        await asyncio.Event().wait()  # la página nunca "se desconecta" a mitad de una petición
        return {"type": "http.disconnect"}

    response: dict[str, Any] = {"status": 500, "headers": [], "body": b""}
    chunks: list[bytes] = []

    async def send(message: dict) -> None:
        if message["type"] == "http.response.start":
            response["status"] = message["status"]
            response["headers"] = [[k.decode("latin-1"), v.decode("latin-1")] for k, v in message.get("headers", [])]
        elif message["type"] == "http.response.body":
            chunks.append(message.get("body", b""))

    try:
        await _state["app"](scope, receive, send)
    except Exception:
        # Starlette ya ha respondido 500 y vuelve a lanzar el error: se registra y se devuelve la respuesta.
        log.exception("Error en %s %s", method, path)
        if not chunks:
            response.update(status=500, headers=[["content-type", "application/json"]])
            chunks.append(b'{"error":"internal","message":"Error interno de la caja. No se ha guardado nada."}')
    response["body"] = b"".join(chunks)
    return response


def snapshot() -> bytes:
    """Copia completa y consistente de la base de datos (para subirla a GitHub)."""
    target = Path("/tmp/copia.sqlite3")
    target.unlink(missing_ok=True)
    _db().backup_to(target)
    try:
        return target.read_bytes()
    finally:
        target.unlink(missing_ok=True)


def shift_excel(shift_id: int) -> list:
    """Nombre y contenido del Excel de cierre de un turno."""
    with _db().read() as conn:
        reports.require_shift(conn, shift_id)
        data = reports.shift_report(conn, shift_id)
    return [_shift_filename(data), shift_workbook(data)]


def restore(content: bytes) -> None:
    """Sustituye la base de datos por una copia, después de comprobarla."""
    if hasattr(content, "to_bytes"):
        content = content.to_bytes()
    candidate = Path("/tmp/restaurar.sqlite3")
    candidate.write_bytes(bytes(content))
    try:
        check = sqlite3.connect(candidate)
        try:
            if check.execute("PRAGMA integrity_check").fetchone()[0] != "ok":
                raise DomainError("invalid_backup", "La copia está dañada.")
            tables = {r[0] for r in check.execute("SELECT name FROM sqlite_master WHERE type = 'table'")}
            if not {"meta", "sales", "shifts", "products"} <= tables:
                raise DomainError("invalid_backup", "Ese archivo no es una copia de la caja CP BAR.")
            if check.execute("PRAGMA user_version").fetchone()[0] > bundled_migrations()[-1][0]:
                raise DomainError("invalid_backup", "La copia es de una versión más nueva de la caja. Actualiza la app.")
        except sqlite3.DatabaseError:
            raise DomainError("invalid_backup", "Ese archivo no es una copia de la caja CP BAR.") from None
        finally:
            check.close()
        settings: Settings = _state["settings"]
        _db().close()
        for suffix in ("-journal", "-wal", "-shm"):
            Path(str(settings.db_path) + suffix).unlink(missing_ok=True)
        settings.db_path.write_bytes(candidate.read_bytes())
    finally:
        candidate.unlink(missing_ok=True)
    start(str(_state["settings"].data_dir))
