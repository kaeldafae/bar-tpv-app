"""Cuentas abiertas a nombre de un cliente.

Una cuenta abierta guarda lo que se le va sirviendo a alguien («la cuenta de Juan»)
y se convierte en una venta normal al cobrarla. Mientras está abierta no es una
venta: no entra en la caja ni descuenta stock. El precio de cada línea es el del
momento en que se sirvió, así que un cambio de precio posterior no la altera.

Cada cambio sube la versión de la cuenta: si dos pantallas tocan la misma cuenta a
la vez, la segunda recibe `tab_changed` y recarga en vez de pisar la primera.
"""

from __future__ import annotations

import json
import sqlite3
from typing import Any

from .db import utc_now
from .errors import Conflict, DomainError, NotFound
from .inventory import log_event
from .sales import MAX_LINE_QTY, LineRequest, SaleRequest, _resolve_line

MAX_LINES = 200


def _row_to_tab(row: sqlite3.Row) -> dict[str, Any]:
    lines = json.loads(row["lines"])
    return {
        "id": row["id"],
        "name": row["name"],
        "lines": lines,
        "version": row["version"],
        "status": row["status"],
        "created_at": row["created_at"],
        "updated_at": row["updated_at"],
        "total_cents": sum(l["unit_price_cents"] * l["qty"] for l in lines),
        "items": sum(l["qty"] for l in lines),
        "sale_id": row["sale_id"],
    }


def get_tab(conn: sqlite3.Connection, tab_id: int) -> dict[str, Any]:
    row = conn.execute("SELECT * FROM open_tabs WHERE id = ?", (tab_id,)).fetchone()
    if row is None:
        raise NotFound("tab_not_found", "Esa cuenta no existe.")
    return _row_to_tab(row)


def require_open_tab(conn: sqlite3.Connection, tab_id: int) -> dict[str, Any]:
    tab = get_tab(conn, tab_id)
    if tab["status"] != "open":
        what = "cobrada" if tab["status"] == "paid" else "eliminada"
        raise Conflict("tab_closed", f"La cuenta de {tab['name']} ya está {what}.")
    return tab


def list_open(conn: sqlite3.Connection) -> list[dict[str, Any]]:
    rows = conn.execute("SELECT * FROM open_tabs WHERE status = 'open' ORDER BY name COLLATE NOCASE").fetchall()
    return [_row_to_tab(r) for r in rows]


def open_summary(conn: sqlite3.Connection) -> dict[str, int]:
    tabs = list_open(conn)
    return {"count": len(tabs), "total_cents": sum(t["total_cents"] for t in tabs)}


def _clean_name(name: str) -> str:
    name = " ".join((name or "").split())
    if not name:
        raise DomainError("name_required", "Escribe el nombre de la cuenta.")
    if len(name) > 60:
        raise DomainError("name_too_long", "El nombre es demasiado largo (máximo 60 letras).")
    return name


def _check_name_free(conn: sqlite3.Connection, name: str, except_id: int | None = None) -> None:
    clash = conn.execute(
        "SELECT id FROM open_tabs WHERE status = 'open' AND name = ? COLLATE NOCASE AND id IS NOT ?",
        (name, except_id),
    ).fetchone()
    if clash:
        raise Conflict("tab_name_taken", f"Ya hay una cuenta abierta a nombre de «{name}». Ábrela o usa otro nombre.",
                       {"id": clash["id"]})


def _line_key(l: dict[str, Any]) -> tuple:
    return (l["product_id"], l.get("licor_option_id"), l.get("refresco_option_id"), l["unit_price_cents"])


def _validate_lines(conn: sqlite3.Connection, lines: list[dict[str, Any]], old: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Comprueba las líneas y junta las repetidas.

    Una línea nueva tiene que ser de un producto a la venta con su precio actual.
    Una línea que ya estaba en la cuenta conserva el precio con el que se sirvió.
    """
    if len(lines) > MAX_LINES:
        raise DomainError("too_many_lines", "La cuenta tiene demasiadas líneas.")
    old_qty: dict[tuple, int] = {}
    old_name: dict[tuple, str] = {}
    for l in old:
        old_qty[_line_key(l)] = old_qty.get(_line_key(l), 0) + l["qty"]
        old_name[_line_key(l)] = l["name"]
    merged: dict[tuple, dict[str, Any]] = {}
    for raw in lines:
        line = {
            "product_id": raw["product_id"],
            "qty": raw["qty"],
            "unit_price_cents": raw["unit_price_cents"],
            "licor_option_id": raw.get("licor_option_id"),
            "refresco_option_id": raw.get("refresco_option_id"),
            "name": "",
        }
        key = _line_key(line)
        if key in merged:
            merged[key]["qty"] += line["qty"]
        else:
            merged[key] = line
        if not 1 <= merged[key]["qty"] <= MAX_LINE_QTY:
            raise DomainError("invalid_qty", "Cantidad no válida.")

    # Lo que se añade ahora se comprueba como una venta: producto a la venta, precio
    # actual y stock suficiente. Lo que ya estaba servido conserva su precio y su nombre.
    needed: dict[int, int] = {}
    for key, line in merged.items():
        added = line["qty"] - old_qty.get(key, 0)
        if key in old_name and added <= 0:
            line["name"] = old_name[key]
            continue
        resolved = _resolve_line(conn, LineRequest(
            product_id=line["product_id"], qty=line["qty"], unit_price_cents=line["unit_price_cents"],
            licor_option_id=line["licor_option_id"], refresco_option_id=line["refresco_option_id"]),
            SaleRequest(id="", kind="venta", lines=[]))
        if key in old_name:
            line["name"] = old_name[key]
        else:
            if resolved.unit_price_cents != line["unit_price_cents"]:
                raise Conflict("price_changed", "Ha cambiado el precio de algún producto. Revisa la cuenta.",
                               [{"product_id": line["product_id"], "name": resolved.name,
                                 "visto": line["unit_price_cents"], "actual": resolved.unit_price_cents}])
            line["name"] = resolved.name
        for ingredient_id, (per_unit, _) in resolved.usage.items():
            needed[ingredient_id] = needed.get(ingredient_id, 0) + per_unit * added
    if needed:
        marks = ",".join("?" * len(needed))
        short = [row["name"] for row in conn.execute(
            f"SELECT id, name, stock_qty FROM ingredients WHERE id IN ({marks})", list(needed))
            if row["stock_qty"] < needed[row["id"]]]
        if short:
            raise Conflict("out_of_stock", f"Agotado: {', '.join(short)}. Registra la compra o un recuento para poder servirlo.")
    return list(merged.values())


def _log_removed(conn: sqlite3.Connection, tab: dict[str, Any], old: list[dict[str, Any]], new: list[dict[str, Any]],
                 device_id: str) -> None:
    """Lo que se quita de una cuenta abierta queda registrado, como en la cuenta normal."""
    remaining = {}
    for l in new:
        remaining[_line_key(l)] = remaining.get(_line_key(l), 0) + l["qty"]
    for l in old:
        k = _line_key(l)
        keep = min(remaining.get(k, 0), l["qty"])
        remaining[k] = remaining.get(k, 0) - keep
        if l["qty"] > keep:
            log_event(conn, "linea_quitada_de_cuenta_abierta", {
                "tab_id": tab["id"], "cuenta": tab["name"], "product_id": l["product_id"], "name": l["name"],
                "qty": l["qty"] - keep, "unit_price_cents": l["unit_price_cents"], "device_id": device_id,
            })


def create_tab(conn: sqlite3.Connection, name: str, lines: list[dict[str, Any]] | None = None,
               device_id: str = "pc") -> dict[str, Any]:
    name = _clean_name(name)
    _check_name_free(conn, name)
    clean = _validate_lines(conn, lines or [], [])
    now = utc_now()
    tab_id = conn.execute(
        "INSERT INTO open_tabs (name, lines, created_at, updated_at) VALUES (?, ?, ?, ?)",
        (name, json.dumps(clean, ensure_ascii=False), now, now),
    ).lastrowid
    log_event(conn, "cuenta_abierta", {"tab_id": tab_id, "cuenta": name, "device_id": device_id})
    return get_tab(conn, tab_id)


def update_tab(conn: sqlite3.Connection, tab_id: int, *, version: int, lines: list[dict[str, Any]] | None = None,
               name: str | None = None, device_id: str = "pc") -> dict[str, Any]:
    tab = require_open_tab(conn, tab_id)
    if tab["version"] != version:
        raise Conflict("tab_changed", f"La cuenta de {tab['name']} ha cambiado en otra pantalla. Se ha recargado.", tab)
    new_name = tab["name"]
    if name is not None:
        new_name = _clean_name(name)
        _check_name_free(conn, new_name, except_id=tab_id)
    new_lines = tab["lines"] if lines is None else _validate_lines(conn, lines, tab["lines"])
    _log_removed(conn, tab, tab["lines"], new_lines, device_id)
    if new_name != tab["name"]:
        log_event(conn, "cuenta_renombrada", {"tab_id": tab_id, "antes": tab["name"], "ahora": new_name})
    conn.execute(
        "UPDATE open_tabs SET name = ?, lines = ?, version = version + 1, updated_at = ? WHERE id = ?",
        (new_name, json.dumps(new_lines, ensure_ascii=False), utc_now(), tab_id),
    )
    return get_tab(conn, tab_id)


def cancel_tab(conn: sqlite3.Connection, tab_id: int, reason: str | None, device_id: str = "pc") -> dict[str, Any]:
    """Elimina una cuenta sin cobrarla. Si tenía algo, el motivo es obligatorio y queda registrado."""
    tab = require_open_tab(conn, tab_id)
    reason = (reason or "").strip()
    if tab["lines"] and not reason:
        raise DomainError("reason_required", "Indica por qué se elimina una cuenta con consumiciones.")
    log_event(conn, "cuenta_eliminada", {"tab_id": tab_id, "cuenta": tab["name"], "lineas": tab["lines"],
                                         "total_cents": tab["total_cents"], "motivo": reason or None, "device_id": device_id})
    conn.execute("UPDATE open_tabs SET status = 'cancelled', closed_at = ?, note = ? WHERE id = ?",
                 (utc_now(), reason or None, tab_id))
    return get_tab(conn, tab_id)


def sale_lines(tab: dict[str, Any]) -> list[LineRequest]:
    return [LineRequest(product_id=l["product_id"], qty=l["qty"], unit_price_cents=l["unit_price_cents"],
                        licor_option_id=l.get("licor_option_id"), refresco_option_id=l.get("refresco_option_id"))
            for l in tab["lines"]]


def mark_paid(conn: sqlite3.Connection, tab_id: int, sale_id: str) -> None:
    conn.execute("UPDATE open_tabs SET status = 'paid', closed_at = ?, sale_id = ? WHERE id = ?",
                 (utc_now(), sale_id, tab_id))
