"""Copias de seguridad automáticas de la base de datos.

Política de conservación: la copia más reciente de cada uno de los últimos 30 días,
de cada uno de los últimos 12 meses y de cada uno de los últimos 6 años
(Código de Comercio, art. 30: conservar la documentación del negocio 6 años).
"""

from __future__ import annotations

import logging
import shutil
import sqlite3
import string
import sys
import threading
from datetime import datetime
from pathlib import Path

from .db import Database

log = logging.getLogger("tpv.backup")

PREFIX = "tpv_"
SUFFIX = ".sqlite3"
STAMP = "%Y-%m-%d_%H%M%S"
KEEP_DAYS, KEEP_MONTHS, KEEP_YEARS = 30, 12, 6
USB_FOLDER = "CPBAR-copias"
USB_KEEP = 30


def _parse(path: Path) -> datetime | None:
    if not (path.name.startswith(PREFIX) and path.name.endswith(SUFFIX)):
        return None
    try:
        return datetime.strptime(path.name[len(PREFIX):-len(SUFFIX)], STAMP)
    except ValueError:
        return None


def files_to_keep(stamps: list[datetime]) -> set[datetime]:
    """Qué copias conservar según la política (la más reciente de cada día, mes y año)."""
    newest_first = sorted(stamps, reverse=True)
    keep: set[datetime] = set()
    for key, limit in ((lambda d: d.date(), KEEP_DAYS), (lambda d: (d.year, d.month), KEEP_MONTHS), (lambda d: d.year, KEEP_YEARS)):
        seen = []
        for stamp in newest_first:
            k = key(stamp)
            if k not in seen:
                seen.append(k)
                if len(seen) > limit:
                    break
                keep.add(stamp)
    return keep


def removable_drives() -> list[Path]:
    """Unidades extraíbles (pendrives) en Windows. En otros sistemas, ninguna."""
    if sys.platform != "win32":
        return []
    import ctypes

    kernel32 = ctypes.windll.kernel32
    mask = kernel32.GetLogicalDrives()
    drives = []
    for i, letter in enumerate(string.ascii_uppercase):
        if mask & (1 << i):
            root = f"{letter}:\\"
            if kernel32.GetDriveTypeW(ctypes.c_wchar_p(root)) == 2:  # DRIVE_REMOVABLE
                drives.append(Path(root))
    return drives


class BackupManager:
    def __init__(self, db: Database, folder: Path, drives=removable_drives, mirror: Path | None = None) -> None:
        self.db = db
        self.folder = Path(folder)
        self._drives = drives
        # Copia extra en la carpeta «TPV BAR» del escritorio (a mano del dueño).
        self.mirror = Path(mirror) if mirror else None
        self._lock = threading.Lock()
        self._stop = threading.Event()
        self.last_error: str | None = None

    def backups(self) -> list[tuple[datetime, Path]]:
        if not self.folder.is_dir():
            return []
        found = [(stamp, p) for p in self.folder.iterdir() if (stamp := _parse(p))]
        return sorted(found, reverse=True)

    def make(self, copy_to_usb: bool = True) -> dict:
        """Hace una copia, comprueba que se puede abrir y aplica la conservación."""
        with self._lock:
            self.folder.mkdir(parents=True, exist_ok=True)
            now = datetime.now()
            target = self.folder / f"{PREFIX}{now.strftime(STAMP)}{SUFFIX}"
            tmp = target.with_suffix(".tmp")
            try:
                self.db.backup_to(tmp)
                check = sqlite3.connect(tmp)
                try:
                    result = check.execute("PRAGMA integrity_check").fetchone()[0]
                finally:
                    check.close()
                if result != "ok":
                    raise RuntimeError(f"La copia no supera la comprobación de integridad: {result}")
                tmp.replace(target)
            except Exception as exc:
                tmp.unlink(missing_ok=True)
                self.last_error = str(exc)
                log.exception("Fallo al hacer la copia de seguridad")
                raise
            self.last_error = None
            self._prune()
            self._mirror(target)
            usb = self._copy_to_usb(target) if copy_to_usb else []
            log.info("Copia de seguridad hecha: %s", target)
            return {"file": str(target), "created_at": now.isoformat(timespec="seconds"), "usb": [str(u) for u in usb]}

    def _prune(self) -> None:
        all_backups = self.backups()
        keep = files_to_keep([s for s, _ in all_backups])
        for stamp, path in all_backups:
            if stamp not in keep:
                path.unlink(missing_ok=True)

    def _mirror(self, source: Path) -> None:
        if self.mirror is None:
            return
        try:
            self.mirror.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, self.mirror / source.name)
            old = sorted((p for p in self.mirror.iterdir() if _parse(p)), key=lambda p: p.name, reverse=True)
            for p in old[USB_KEEP:]:
                p.unlink(missing_ok=True)
        except OSError:
            log.exception("No se pudo copiar la copia de seguridad a %s", self.mirror)

    def _copy_to_usb(self, source: Path) -> list[Path]:
        copied = []
        for drive in self._drives():
            try:
                dest_dir = drive / USB_FOLDER
                dest_dir.mkdir(exist_ok=True)
                shutil.copy2(source, dest_dir / source.name)
                old = sorted((p for p in dest_dir.iterdir() if _parse(p)), key=lambda p: p.name, reverse=True)
                for p in old[USB_KEEP:]:
                    p.unlink(missing_ok=True)
                copied.append(dest_dir)
            except OSError:
                log.exception("No se pudo copiar al pendrive %s", drive)
        return copied

    def ensure_today(self) -> None:
        latest = self.backups()
        if not latest or latest[0][0].date() < datetime.now().date():
            try:
                self.make(copy_to_usb=False)
            except Exception:
                pass

    def status(self) -> dict:
        items = self.backups()
        return {
            "folder": str(self.folder),
            "count": len(items),
            "latest": items[0][0].isoformat(timespec="seconds") if items else None,
            "last_error": self.last_error,
            "usb_drives": [str(d) for d in self._drives()],
        }

    def start_daily(self, interval_seconds: int = 3600) -> threading.Thread:
        """Comprueba cada hora si ya hay copia de hoy; si no, la hace."""
        def loop() -> None:
            while not self._stop.is_set():
                self.ensure_today()
                self._stop.wait(interval_seconds)

        thread = threading.Thread(target=loop, name="copias", daemon=True)
        thread.start()
        return thread

    def stop(self) -> None:
        self._stop.set()
