from __future__ import annotations

from typing import Any


class DomainError(Exception):
    """Error de negocio con un mensaje apto para mostrar en pantalla."""

    status = 400

    def __init__(self, code: str, message: str, details: Any = None) -> None:
        super().__init__(message)
        self.code = code
        self.message = message
        self.details = details


class NotFound(DomainError):
    status = 404


class Conflict(DomainError):
    status = 409


class Unauthorized(DomainError):
    status = 401


class TooManyAttempts(DomainError):
    status = 429
