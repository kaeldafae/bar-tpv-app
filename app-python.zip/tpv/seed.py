"""Datos de EJEMPLO con precios ficticios, para probar la app antes de cargar los reales."""

from __future__ import annotations

import sqlite3

from . import catalog

DEMO_FLAG = "demo_data"

CATEGORIES = [
    ("Ron", "#B45309"), ("Whisky", "#7C4A1E"), ("Cervezas", "#CA8A04"),
    ("Combinados", "#BE185D"), ("Refrescos", "#0369A1"), ("Comida", "#6D28D9"),
]

# sección, nombre, precio (céntimos)
SIMPLE_PRODUCTS = [
    ("Ron", "Copa Brugal Añejo", 600), ("Ron", "Copa Barceló Añejo", 600),
    ("Ron", "Copa Brugal Extra Viejo", 750), ("Ron", "Copa Barceló Imperial", 900),
    ("Whisky", "Copa J&B", 700), ("Whisky", "Copa Johnnie Walker Red", 750),
    ("Cervezas", "Presidente 33 cl", 300), ("Cervezas", "Mahou 33 cl", 250),
    ("Refrescos", "Coca-Cola", 250), ("Refrescos", "Coca-Cola Zero", 250), ("Refrescos", "Fanta Naranja", 250),
    ("Refrescos", "Sprite", 250), ("Refrescos", "Tónica", 250), ("Refrescos", "Agua", 150),
    ("Comida", "Plato de sancocho", 750), ("Comida", "Empanada dominicana", 250),
]

COMBO_SPIRITS = [
    ("Brugal Añejo", 750), ("Barceló Añejo", 800), ("Brugal Extra Viejo", 900),
    ("Barceló Imperial", 1100), ("J&B", 800), ("Johnnie Walker Red", 850),
]
COMBO_MIXERS = ["Coca-Cola", "Coca-Cola Zero", "Fanta Naranja", "Sprite", "Tónica", "Solo hielo"]


def seed_examples(conn: sqlite3.Connection) -> bool:
    """Carga el ejemplo solo en una base vacía. Devuelve True si cargó algo."""
    if conn.execute("SELECT 1 FROM categories LIMIT 1").fetchone():
        return False
    cats = {name: catalog.create_category(conn, name=name, color=color) for name, color in CATEGORIES}
    for cat, name, price in SIMPLE_PRODUCTS:
        catalog.create_product(conn, category_id=cats[cat], name=name, price_cents=price)
    options = [{"grp": "licor", "label": label, "price_cents": price} for label, price in COMBO_SPIRITS]
    options += [{"grp": "refresco", "label": label} for label in COMBO_MIXERS]
    catalog.create_product(conn, category_id=cats["Combinados"], name="Combinado", kind="combinado", price_cents=0, options=options)
    conn.execute("INSERT INTO meta (key, value) VALUES (?, '1')", (DEMO_FLAG,))
    return True
