"""Datos de EJEMPLO con precios y costes ficticios, para probar la app antes de cargar los reales."""

from __future__ import annotations

import sqlite3

from . import catalog, inventory

DEMO_FLAG = "demo_data"

CATEGORIES = [
    ("Ron", "#9A4F12"), ("Whisky", "#6B4226"), ("Cervezas", "#8A6A0C"),
    ("Combinados", "#9E2A52"), ("Refrescos", "#1D6688"), ("Comida", "#5B3EA0"),
]

# nombre, unidad, tamaño envase, etiqueta, coste envase (céntimos), envases en stock, mínimo (unidad base)
INGREDIENTS = [
    ("Ron Brugal Añejo", "ml", 700, "Botella 70 cl", 1200, 3, 700),
    ("Ron Barceló Añejo", "ml", 700, "Botella 70 cl", 1300, 3, 700),
    ("Ron Brugal Extra Viejo", "ml", 700, "Botella 70 cl", 1600, 2, 700),
    ("Ron Barceló Imperial", "ml", 700, "Botella 70 cl", 2400, 0, 700),
    ("Whisky J&B", "ml", 700, "Botella 70 cl", 1100, 2, 700),
    ("Whisky Johnnie Walker Red", "ml", 700, "Botella 70 cl", 1300, 2, 700),
    ("Cerveza Presidente 33 cl", "ud", 1, "Botellín", 90, 48, 12),
    ("Cerveza Mahou 33 cl", "ud", 1, "Botellín", 60, 48, 12),
    ("Coca-Cola 33 cl", "ud", 1, "Lata", 45, 48, 12),
    ("Coca-Cola Zero 33 cl", "ud", 1, "Lata", 45, 24, 6),
    ("Fanta Naranja 33 cl", "ud", 1, "Lata", 42, 24, 6),
    ("Sprite 33 cl", "ud", 1, "Lata", 42, 24, 6),
    ("Tónica 20 cl", "ud", 1, "Botellín", 55, 24, 6),
    ("Sancocho", "racion", 1, "Ración", 210, 12, 4),
    ("Empanada dominicana", "racion", 1, "Unidad", 65, 0, 6),
]

POUR_ML = 50

SIMPLE_PRODUCTS = [
    ("Ron", "Copa Brugal Añejo", 600, [("Ron Brugal Añejo", POUR_ML)]),
    ("Ron", "Copa Barceló Añejo", 600, [("Ron Barceló Añejo", POUR_ML)]),
    ("Ron", "Copa Brugal Extra Viejo", 750, [("Ron Brugal Extra Viejo", POUR_ML)]),
    ("Ron", "Copa Barceló Imperial", 900, [("Ron Barceló Imperial", POUR_ML)]),
    ("Whisky", "Copa J&B", 700, [("Whisky J&B", POUR_ML)]),
    ("Whisky", "Copa Johnnie Walker Red", 750, [("Whisky Johnnie Walker Red", POUR_ML)]),
    ("Cervezas", "Presidente 33 cl", 300, [("Cerveza Presidente 33 cl", 1)]),
    ("Cervezas", "Mahou 33 cl", 250, [("Cerveza Mahou 33 cl", 1)]),
    ("Refrescos", "Coca-Cola", 250, [("Coca-Cola 33 cl", 1)]),
    ("Refrescos", "Coca-Cola Zero", 250, [("Coca-Cola Zero 33 cl", 1)]),
    ("Refrescos", "Fanta Naranja", 250, [("Fanta Naranja 33 cl", 1)]),
    ("Refrescos", "Sprite", 250, [("Sprite 33 cl", 1)]),
    ("Refrescos", "Tónica", 250, [("Tónica 20 cl", 1)]),
    ("Comida", "Plato de sancocho", 750, [("Sancocho", 1)]),
    ("Comida", "Empanada dominicana", 250, [("Empanada dominicana", 1)]),
]

COMBO_SPIRITS = [
    ("Brugal Añejo", "Ron Brugal Añejo", 750), ("Barceló Añejo", "Ron Barceló Añejo", 800),
    ("Brugal Extra Viejo", "Ron Brugal Extra Viejo", 900), ("Barceló Imperial", "Ron Barceló Imperial", 1100),
    ("J&B", "Whisky J&B", 800), ("Johnnie Walker Red", "Whisky Johnnie Walker Red", 850),
]
COMBO_MIXERS = [
    ("Coca-Cola", "Coca-Cola 33 cl"), ("Coca-Cola Zero", "Coca-Cola Zero 33 cl"), ("Fanta Naranja", "Fanta Naranja 33 cl"),
    ("Sprite", "Sprite 33 cl"), ("Tónica", "Tónica 20 cl"), ("Solo hielo", None),
]


def seed_examples(conn: sqlite3.Connection) -> bool:
    """Carga el ejemplo solo en una base vacía. Devuelve True si cargó algo."""
    if conn.execute("SELECT 1 FROM categories LIMIT 1").fetchone():
        return False
    cats = {name: catalog.create_category(conn, name=name, color=color) for name, color in CATEGORIES}
    ings = {}
    for name, unit, size, label, pkg_cost, pkgs, min_stock in INGREDIENTS:
        ings[name] = inventory.create_ingredient(
            conn, name=name, unit=unit, package_size=size, package_label=label, min_stock=min_stock,
            initial_qty=size * pkgs, initial_total_cents=pkg_cost * pkgs,
        )
        if pkgs == 0:
            # Sin stock, pero con coste de referencia para calcular márgenes.
            conn.execute("UPDATE ingredients SET cost_mc = ? WHERE id = ?", (pkg_cost * 1000 // size, ings[name]))
    for cat, name, price, recipe in SIMPLE_PRODUCTS:
        catalog.create_product(
            conn, category_id=cats[cat], name=name, price_cents=price,
            recipe=[{"ingredient_id": ings[i], "qty": q} for i, q in recipe],
        )
    options = [
        {"grp": "licor", "label": label, "ingredient_id": ings[ing], "qty": POUR_ML, "price_cents": price}
        for label, ing, price in COMBO_SPIRITS
    ] + [
        {"grp": "refresco", "label": label, "ingredient_id": ings[ing] if ing else None, "qty": 1 if ing else 0}
        for label, ing in COMBO_MIXERS
    ]
    catalog.create_product(conn, category_id=cats["Combinados"], name="Combinado", kind="combinado", price_cents=0, options=options)
    conn.execute("INSERT INTO meta (key, value) VALUES (?, '1')", (DEMO_FLAG,))
    return True
