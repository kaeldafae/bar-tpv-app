"""Insumos, stock teórico y coste medio ponderado (PMP)."""

from __future__ import annotations

import json
import sqlite3
from typing import Any

from .db import utc_now
from .errors import Conflict, DomainError, NotFound
from .money import MC_PER_CENT, div_round

UNITS = ("ml", "ud", "racion")


def weighted_cost(stock_qty: int, cost_mc: int, add_qty: int, add_total_cents: int) -> int:
    """Nuevo coste unitario tras una entrada.

    Si no había stock positivo, el coste pasa a ser el de la entrada: mezclar con
    un stock negativo o nulo daría un coste sin sentido.
    """
    if add_qty <= 0:
        raise DomainError("invalid_qty", "La cantidad debe ser mayor que cero.")
    if add_total_cents < 0:
        raise DomainError("invalid_cost", "El coste no puede ser negativo.")
    if stock_qty <= 0:
        return div_round(add_total_cents * MC_PER_CENT, add_qty)
    return div_round(stock_qty * cost_mc + add_total_cents * MC_PER_CENT, stock_qty + add_qty)


def get_ingredient(conn: sqlite3.Connection, ingredient_id: int) -> sqlite3.Row:
    row = conn.execute("SELECT * FROM ingredients WHERE id = ?", (ingredient_id,)).fetchone()
    if row is None:
        raise NotFound("ingredient_not_found", "Ese insumo no existe.")
    return row


def log_event(conn: sqlite3.Connection, type_: str, payload: dict[str, Any]) -> None:
    conn.execute(
        "INSERT INTO events (created_at, type, payload) VALUES (?, ?, ?)",
        (utc_now(), type_, json.dumps(payload, ensure_ascii=False, sort_keys=True)),
    )


def apply_movement(
    conn: sqlite3.Connection,
    ingredient_id: int,
    delta: int,
    kind: str,
    unit_cost_mc: int,
    *,
    total_cents: int | None = None,
    ref: str | None = None,
    note: str | None = None,
    shift_id: int | None = None,
) -> None:
    conn.execute(
        "INSERT INTO stock_movements (ingredient_id, delta, kind, unit_cost_mc, total_cents, ref, note, shift_id, created_at)"
        " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
        (ingredient_id, delta, kind, unit_cost_mc, total_cents, ref, note, shift_id, utc_now()),
    )
    conn.execute("UPDATE ingredients SET stock_qty = stock_qty + ? WHERE id = ?", (delta, ingredient_id))


def _validate_fields(name: str, unit: str, package_size: int, min_stock: int) -> str:
    name = name.strip()
    if not name:
        raise DomainError("name_required", "El nombre es obligatorio.")
    if unit not in UNITS:
        raise DomainError("invalid_unit", "Unidad no válida.")
    if package_size <= 0:
        raise DomainError("invalid_package", "El tamaño del envase debe ser mayor que cero.")
    if min_stock < 0:
        raise DomainError("invalid_min_stock", "El stock mínimo no puede ser negativo.")
    return name


def _ensure_unique_name(conn: sqlite3.Connection, name: str, exclude_id: int | None = None) -> None:
    row = conn.execute(
        "SELECT id FROM ingredients WHERE archived = 0 AND name = ? COLLATE NOCASE AND id IS NOT ?",
        (name, exclude_id),
    ).fetchone()
    if row is not None:
        raise Conflict("duplicate_name", f"Ya existe un insumo llamado «{name}».")


def create_ingredient(
    conn: sqlite3.Connection,
    *,
    name: str,
    unit: str,
    package_size: int,
    package_label: str,
    min_stock: int = 0,
    initial_qty: int = 0,
    initial_total_cents: int = 0,
) -> int:
    name = _validate_fields(name, unit, package_size, min_stock)
    _ensure_unique_name(conn, name)
    if initial_qty < 0:
        raise DomainError("invalid_qty", "El stock inicial no puede ser negativo.")
    cur = conn.execute(
        "INSERT INTO ingredients (name, unit, package_size, package_label, min_stock) VALUES (?, ?, ?, ?, ?)",
        (name, unit, package_size, package_label.strip() or name, min_stock),
    )
    ingredient_id = cur.lastrowid
    if initial_qty > 0:
        cost = weighted_cost(0, 0, initial_qty, initial_total_cents)
        conn.execute("UPDATE ingredients SET cost_mc = ? WHERE id = ?", (cost, ingredient_id))
        apply_movement(conn, ingredient_id, initial_qty, "inicial", cost, total_cents=initial_total_cents)
    return ingredient_id


def update_ingredient(conn: sqlite3.Connection, ingredient_id: int, **fields: Any) -> None:
    current = get_ingredient(conn, ingredient_id)
    if current["archived"]:
        raise Conflict("archived", "Ese insumo está eliminado.")
    merged = {k: current[k] for k in ("name", "unit", "package_size", "package_label", "min_stock")}
    merged.update({k: v for k, v in fields.items() if v is not None})
    if merged["unit"] != current["unit"]:
        used = conn.execute("SELECT 1 FROM stock_movements WHERE ingredient_id = ? LIMIT 1", (ingredient_id,)).fetchone()
        if used:
            raise Conflict("unit_locked", "No se puede cambiar la unidad de un insumo que ya tiene movimientos.")
    name = _validate_fields(merged["name"], merged["unit"], merged["package_size"], merged["min_stock"])
    _ensure_unique_name(conn, name, ingredient_id)
    conn.execute(
        "UPDATE ingredients SET name = ?, unit = ?, package_size = ?, package_label = ?, min_stock = ? WHERE id = ?",
        (name, merged["unit"], merged["package_size"], merged["package_label"], merged["min_stock"], ingredient_id),
    )


def delete_ingredient(conn: sqlite3.Connection, ingredient_id: int) -> str:
    """Borra si nunca se usó; si tiene historial, lo archiva. Devuelve 'deleted' o 'archived'."""
    get_ingredient(conn, ingredient_id)
    in_recipe = conn.execute(
        "SELECT p.name FROM recipe_items r JOIN products p ON p.id = r.product_id"
        " WHERE r.ingredient_id = ? AND p.archived = 0"
        " UNION SELECT p.name FROM combo_options o JOIN products p ON p.id = o.product_id"
        " WHERE o.ingredient_id = ? AND o.archived = 0 AND p.archived = 0",
        (ingredient_id, ingredient_id),
    ).fetchall()
    if in_recipe:
        names = ", ".join(r[0] for r in in_recipe)
        raise Conflict("ingredient_in_use", f"Se usa en: {names}. Quítalo de esas recetas primero.")
    history = conn.execute(
        "SELECT 1 FROM stock_movements WHERE ingredient_id = ?"
        " UNION ALL SELECT 1 FROM sale_line_usage WHERE ingredient_id = ?"
        " UNION ALL SELECT 1 FROM recipe_items WHERE ingredient_id = ?"
        " UNION ALL SELECT 1 FROM combo_options WHERE ingredient_id = ? LIMIT 1",
        (ingredient_id,) * 4,
    ).fetchone()
    if history:
        conn.execute("UPDATE ingredients SET archived = 1 WHERE id = ?", (ingredient_id,))
        return "archived"
    conn.execute("DELETE FROM ingredients WHERE id = ?", (ingredient_id,))
    return "deleted"


def record_entry(
    conn: sqlite3.Connection,
    ingredient_id: int,
    *,
    qty: int,
    total_cents: int,
    kind: str = "compra",
    note: str | None = None,
    shift_id: int | None = None,
) -> int:
    """Compra o producción: suma stock y recalcula el coste medio. Devuelve el nuevo coste (mc)."""
    if kind not in ("compra", "produccion"):
        raise DomainError("invalid_kind", "Tipo de entrada no válido.")
    ing = get_ingredient(conn, ingredient_id)
    if ing["archived"]:
        raise Conflict("archived", "Ese insumo está eliminado.")
    new_cost = weighted_cost(ing["stock_qty"], ing["cost_mc"], qty, total_cents)
    conn.execute("UPDATE ingredients SET cost_mc = ? WHERE id = ?", (new_cost, ingredient_id))
    apply_movement(
        conn, ingredient_id, qty, kind, div_round(total_cents * MC_PER_CENT, qty),
        total_cents=total_cents, note=note, shift_id=shift_id,
    )
    return new_cost


def record_waste(
    conn: sqlite3.Connection, ingredient_id: int, *, qty: int, note: str, shift_id: int | None = None
) -> None:
    if qty <= 0:
        raise DomainError("invalid_qty", "La cantidad debe ser mayor que cero.")
    if not note.strip():
        raise DomainError("reason_required", "Indica el motivo de la merma.")
    ing = get_ingredient(conn, ingredient_id)
    apply_movement(conn, ingredient_id, -qty, "merma", ing["cost_mc"], note=note.strip(), shift_id=shift_id)


def record_count(conn: sqlite3.Connection, items: list[tuple[int, int]], note: str | None = None) -> dict[str, Any]:
    """Recuento físico: fija el stock al contado y guarda la diferencia con el teórico."""
    if not items:
        raise DomainError("empty_count", "No hay nada que contar.")
    seen: set[int] = set()
    for ingredient_id, counted in items:
        if ingredient_id in seen:
            raise DomainError("duplicate_item", "Un insumo aparece dos veces en el recuento.")
        if counted < 0:
            raise DomainError("invalid_qty", "Lo contado no puede ser negativo.")
        seen.add(ingredient_id)
    cur = conn.execute("INSERT INTO stock_counts (created_at, note) VALUES (?, ?)", (utc_now(), note))
    count_id = cur.lastrowid
    lines = []
    for ingredient_id, counted in items:
        ing = get_ingredient(conn, ingredient_id)
        diff = counted - ing["stock_qty"]
        conn.execute(
            "INSERT INTO stock_count_lines (count_id, ingredient_id, theoretical, counted, unit_cost_mc) VALUES (?, ?, ?, ?, ?)",
            (count_id, ingredient_id, ing["stock_qty"], counted, ing["cost_mc"]),
        )
        if diff:
            apply_movement(conn, ingredient_id, diff, "recuento", ing["cost_mc"], ref=f"recuento:{count_id}")
        lines.append({
            "ingredient_id": ingredient_id,
            "name": ing["name"],
            "theoretical": ing["stock_qty"],
            "counted": counted,
            "difference": diff,
            "difference_value_cents": div_round(diff * ing["cost_mc"], MC_PER_CENT),
        })
    return {"count_id": count_id, "lines": lines}


def stock_status(stock_qty: int, min_stock: int) -> str:
    if stock_qty <= 0:
        return "agotado"
    if stock_qty <= min_stock:
        return "bajo"
    return "ok"


def list_ingredients(conn: sqlite3.Connection) -> list[dict[str, Any]]:
    rows = conn.execute("SELECT * FROM ingredients WHERE archived = 0 ORDER BY name COLLATE NOCASE").fetchall()
    return [
        {
            "id": r["id"],
            "name": r["name"],
            "unit": r["unit"],
            "package_size": r["package_size"],
            "package_label": r["package_label"],
            "stock_qty": r["stock_qty"],
            "min_stock": r["min_stock"],
            "cost_mc": r["cost_mc"],
            "package_cost_cents": div_round(r["cost_mc"] * r["package_size"], MC_PER_CENT),
            "stock_value_cents": div_round(max(r["stock_qty"], 0) * r["cost_mc"], MC_PER_CENT),
            "status": stock_status(r["stock_qty"], r["min_stock"]),
        }
        for r in rows
    ]
