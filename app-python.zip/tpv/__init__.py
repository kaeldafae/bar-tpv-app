"""TPV de CP BAR: servidor local de ventas, caja e inventario."""

__version__ = "1.2.0"
