"""TPV de CP BAR: ventas, cobros, cuentas abiertas y caja."""

__version__ = "1.3.0"
