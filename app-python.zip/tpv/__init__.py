"""TPV de CP BAR: ventas, cobros, cuentas abiertas y caja."""

__version__ = "1.4.0"
