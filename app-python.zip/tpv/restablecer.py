"""Restablece la contraseña de administración desde el propio ordenador del bar.

Uso: python -m tpv.restablecer  (lo lanza windows\\restablecer-contrasena.bat)
Solo funciona con acceso físico al PC: no hay forma de hacerlo por la red.
"""

from __future__ import annotations

import getpass
import sys

from . import admin
from .config import Settings
from .db import Database
from .errors import DomainError


def main() -> int:
    settings = Settings.from_env()
    if not settings.db_path.exists():
        print(f"No se encuentra la base de datos en {settings.db_path}.")
        return 1
    print("Restablecer la contraseña de administración de CP BAR")
    print("(lo que escribas no se verá en pantalla)\n")
    first = getpass.getpass("Nueva contraseña (mínimo 8 caracteres): ")
    second = getpass.getpass("Repítela: ")
    if first != second:
        print("\nLas contraseñas no coinciden. No se ha cambiado nada.")
        return 1
    db = Database(settings.db_path)
    try:
        with db.tx() as conn:
            admin.reset_password(conn, first)
    except DomainError as exc:
        print(f"\n{exc.message} No se ha cambiado nada.")
        return 1
    finally:
        db.close()
    print("\nContraseña cambiada. Si la caja estaba abierta, vuelve a entrar en Admin.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
