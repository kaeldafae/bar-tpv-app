"""Dinero en céntimos enteros; costes en milésimas de céntimo (mc)."""

from __future__ import annotations

MC_PER_CENT = 1000


def div_round(numerator: int, denominator: int) -> int:
    """División entera redondeando al más cercano (mitades hacia arriba) para valores no negativos."""
    if denominator <= 0:
        raise ValueError("El divisor debe ser positivo")
    if numerator < 0:
        return -div_round(-numerator, denominator)
    return (2 * numerator + denominator) // (2 * denominator)


def mc_to_cents(mc: int) -> int:
    return div_round(mc, MC_PER_CENT)


def format_eur(cents: int) -> str:
    """1234,5 € con separador de miles: format_eur(123450) -> '1.234,50 €'."""
    sign = "-" if cents < 0 else ""
    cents = abs(cents)
    euros, rest = divmod(cents, 100)
    return f"{sign}{euros:,}".replace(",", ".") + f",{rest:02d} €"


def margin_pct(price_cents: int, cost_cents: int) -> float | None:
    """Margen sobre el precio de venta, en %. None si el precio es 0."""
    if price_cents <= 0:
        return None
    return round((price_cents - cost_cents) * 100 / price_cents, 1)
